# BUILD SAMSSZ MOBILE 4.0 -> APK

PENTING: jangan mengganti nama `.zip` menjadi `.apk`. APK harus di-build oleh Android build system.

## Cara paling gampang: Android Studio / AndroidIDE

1. Extract ZIP.
2. Buka folder `SAMSSZ_Mobile` sebagai project Gradle.
3. Pastikan Android SDK Platform 35 dan JDK 17 tersedia.
4. Tunggu Gradle sync selesai.
5. Jalankan:

   `gradle :app:assembleDebug`

6. APK hasilnya:

   `app/build/outputs/apk/debug/app-debug.apk`

APK debug tersebut bisa langsung dipasang di Android dengan mengizinkan instalasi dari sumber yang dipilih.

## Tanpa build lokal: GitHub Actions

Folder `.github/workflows/build-apk.yml` sudah disediakan.

1. Upload seluruh folder project ke repository GitHub.
2. Buka tab **Actions**.
3. Pilih **Build SAMSSZ Mobile APK**.
4. Jalankan workflow.
5. Setelah selesai, download artifact **SAMSSZ-Mobile-debug**.
6. Di dalamnya ada `app-debug.apk`.

## Isi versi ini

- SAMSSZ Mobile UI.
- Folder picker Android (SAF).
- PC -> PS4 model conversion.
- PS4 -> PC model conversion.
- Recursive folder scan.
- ZIP archive scan.
- RSC7 raw-deflate decode/re-encode.
- GTAV1 <-> PS4 byte patch.
- Duplicate-safe output naming.
- 11 menu utama.

## Batasan penting

`ragebuilder.exe`, Wine/xow64, dan runtime Windows yang dipakai jalur RPF/OTD dari tool Python asli tidak otomatis menjadi executable Android hanya karena dimasukkan ke APK. Menu RPF/OTD karena itu tetap diberi penanda runtime desktop dan tidak berpura-pura menjadi native Android.

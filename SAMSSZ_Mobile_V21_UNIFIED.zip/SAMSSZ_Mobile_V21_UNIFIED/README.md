# SAMSSZ Mobile V16 — Full Python/OTD Engine Edition

This build keeps the existing native UI/UX and routes converter operations through an embedded Python engine based on the supplied `SamsszConverter.py`.

## Engine basis
- `app/src/main/python/SamsszConverter.py` — supplied Python converter source.
- `app/src/main/python/SamsszRenamer.py` — supplied family renamer source.
- `app/src/main/python/samssz_mobile_backend.py` — Android bridge which invokes the supplied Python model/RPF/YTD engines without the interactive terminal prompts.
- Existing Java UI/UX remains in `MainActivity.java`.

## Important behavior kept from the request
- Convert to PC scans PS4 model resources only. ZIP/archive contents are NOT included in Convert to PC.
- Family Renamer keeps matching ZIPs attached to the same OFT/OTD family.
- ZIP family naming follows the supplied renamer convention and matching OFT/OTD entries inside ZIP are renamed.
- Existing AI modes and UI are retained.
- SAMSSZ wordmark is modernized with neon shadow/line elements without changing the screen layout.

## Android engine note
The Python model converter, RPF extractor and YTD extractor can run through Chaquopy. The OTD path now calls the exact embedded `OTD_ENGINE` from the supplied `SamsszConverter.py`, including the embedded `ragebuilder.exe`, DLLs and `texture_builder.lua`. The app no longer hard-codes OTD as unsupported. Actual execution of the embedded Windows PE builder still requires a compatible Windows/x86-64 runtime layer on Android; the app reports the real runtime error if that layer is unavailable instead of fabricating an output.


## OTD runtime
The Android OTD path now exports the selected runtime through HOME/PATH/SAMSSZ_RUNTIME_DIR before invoking the original embedded OTD engine. A build is counted as successful only when the requested `.otd` file is actually created and has non-zero size.

import os, json, shutil, zipfile, tempfile, traceback
from pathlib import Path

import SamsszConverter as sc

PC_TO_PS4 = sc.MODEL_ENGINE["PC_TO_PS4"]
PS4_TO_PC = sc.MODEL_ENGINE["PS4_TO_PC"]
MODEL_EXTS = set(PC_TO_PS4) | set(PS4_TO_PC)
PC_EXTS = set(PC_TO_PS4)
PS4_EXTS = set(PS4_TO_PC)


def _files(root, *, recursive=True):
    """Return actual input files only; generated/cache trees are excluded."""
    root=Path(root); skip={"Samssz_Converted","Samssz_Auto_Workspace","__pycache__","Build","otd_runtime"}
    it=root.rglob("*") if recursive else root.glob("*")
    out=[]
    for p in it:
        if not p.is_file(): continue
        rel=p.relative_to(root)
        if any(part in skip for part in rel.parts): continue
        out.append(p)
    return sorted(out,key=lambda x:x.relative_to(root).as_posix().lower())

def _model_candidates(root,direction='both'):
    out=[]
    for p in _files(root):
        ext=p.suffix.lower()
        if ext not in MODEL_EXTS: continue
        if direction=='pc2ps4' and ext not in PC_EXTS: continue
        if direction=='ps42pc' and ext not in PS4_EXTS: continue
        out.append(p)
    return out


def _convert_file(p, direction=None):
    ext=p.suffix.lower()
    if direction=='pc2ps4' and ext not in PC_EXTS: return False
    if direction=='ps42pc' and ext not in PS4_EXTS: return False
    return bool(sc.MODEL_ENGINE['process_file'](str(p), 0))


def convert_models(root,direction='both'):
    root=Path(root); candidates=_model_candidates(root,direction); ok=[]; fail=[]
    for p in candidates:
        rel=str(p.relative_to(root))
        try:
            if _convert_file(p,direction): ok.append(rel)
            else: fail.append(rel)
        except Exception as e: fail.append(f"{rel} :: {e}")
    return {'operation':'convert','detected':len(candidates),'processed':len(candidates),
            'success':len(ok),'failed':len(fail),'found':[str(p.relative_to(root)) for p in candidates],
            'ok':ok,'fail':fail}


def extract_rpf_one(src,dest):
    eng=sc.load_rpf_engine()
    eng['extract'](str(src),str(dest))


def extract_all(root):
    root=Path(root); results=[]
    for p in _files(root):
        ext=p.suffix.lower()
        try:
            if ext=='.rpf':
                d=p.with_suffix('')
                if d.exists(): d=Path(str(d)+'_extracted')
                extract_rpf_one(p,d); results.append({'type':'rpf','src':str(p.relative_to(root)),'dest':str(d.relative_to(root)),'ok':True})
            elif ext=='.ytd':
                d=p.with_suffix('')
                if d.exists(): d=Path(str(d)+'_extracted')
                sc.YTD_ENGINE['extract_ytd'](str(p),str(d)); results.append({'type':'ytd','src':str(p.relative_to(root)),'dest':str(d.relative_to(root)),'ok':True})
        except Exception as e:
            results.append({'type':ext,'src':str(p.relative_to(root)),'ok':False,'error':str(e)})
    return {'operation':'extract','results':results}


def _is_dlc(p):
    return sc._is_dlc_rpf_name(p)

def _is_vehicles(p):
    return sc._is_vehicles_rpf_name(p)


def _target_rpfs(root):
    rpfs=[p for p in Path(root).rglob('*.rpf') if p.is_file()]
    veh=[p for p in rpfs if _is_vehicles(p)]
    dlc=[p for p in rpfs if _is_dlc(p)]
    return sorted(set(veh or dlc), key=lambda x:str(x).lower())


def _zip_extract(src,dst):
    dst=Path(dst); dst.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(src,'r') as z:
        for i in z.infolist():
            name=Path(i.filename)
            if name.is_absolute() or '..' in name.parts: continue
            out=(dst/name).resolve()
            if not str(out).startswith(str(dst.resolve())): continue
            if i.is_dir(): out.mkdir(parents=True,exist_ok=True)
            else:
                out.parent.mkdir(parents=True,exist_ok=True)
                with z.open(i) as a, open(out,'wb') as b: shutil.copyfileobj(a,b)


def auto_scan(root):
    root=Path(root); workspace=Path(tempfile.mkdtemp(prefix='samssz_mobile_auto_')); generated=[]; report=[]
    try:
        archives=[p for p in _files(root) if p.suffix.lower() in {'.zip','.7z','.rar','.tar','.tgz','.gz','.bz2','.xz'}]
        loose=[p for p in _files(root) if p.suffix.lower()=='.rpf']
        for idx,a in enumerate(archives):
            aw=workspace/f'archive_{idx}'; aw.mkdir(parents=True,exist_ok=True)
            try:
                if a.suffix.lower()=='.zip': _zip_extract(a,aw)
                else:
                    ok,detail=sc._auto_extract_archive(a,aw)
                    if not ok: report.append({'archive':str(a.relative_to(root)),'skip':detail}); continue
                targets=_target_rpfs(aw)
                for rpf in targets:
                    tw=workspace/(f'target_{idx}_{abs(hash(str(rpf)))%1000000000}'); tw.mkdir(parents=True,exist_ok=True)
                    try:
                        extract_rpf_one(rpf,tw)
                        pc=[p for p in _files(tw) if p.suffix.lower() in PC_EXTS]
                        for p in pc:
                            if _convert_file(p,'pc2ps4'): generated.append(p)
                        for ytd in [p for p in _files(tw) if p.suffix.lower()=='.ytd']:
                            try:
                                d=ytd.with_suffix(''); sc.YTD_ENGINE['extract_ytd'](str(ytd),str(d))
                            except Exception as e: report.append({'rpf':rpf.name,'ytd':ytd.name,'error':str(e)})
                    except Exception as e: report.append({'rpf':str(rpf),'error':str(e)})
            except Exception as e: report.append({'archive':str(a.relative_to(root)),'error':str(e)})
        # loose entry RPFs
        for rpf in loose:
            try:
                tw=workspace/(f'loose_{abs(hash(str(rpf)))%1000000000}'); tw.mkdir(parents=True,exist_ok=True)
                if rpf.resolve() not in [x.resolve() for x in _target_rpfs(root)]: continue
                extract_rpf_one(rpf,tw)
                for p in [p for p in _files(tw) if p.suffix.lower() in PC_EXTS]:
                    if _convert_file(p,'pc2ps4'): generated.append(p)
            except Exception as e: report.append({'rpf':str(rpf.relative_to(root)),'error':str(e)})
        outdir=root/'Samssz_Converted'/'AUTO_SCAN'; outdir.mkdir(parents=True,exist_ok=True)
        published=[]
        for p in generated:
            if p.is_file():
                fam=sc._smart_model_base(p.stem); fd=outdir/fam; fd.mkdir(parents=True,exist_ok=True)
                dst=fd/p.name; shutil.copy2(p,dst); published.append(dst)
        return {'operation':'auto_scan','generated':[str(p.relative_to(root)) for p in published],'count':len(published),'report':report}
    finally:
        shutil.rmtree(workspace,ignore_errors=True)



def build_rpf(root):
    """Build an unencrypted RPF7 from the selected folder tree.
    This is the mobile-safe counterpart of the Python toolkit's RPF build target.
    """
    root=Path(root); outdir=root/'Build'; outdir.mkdir(exist_ok=True)
    files=[p for p in root.rglob('*') if p.is_file() and outdir not in p.parents and p!=outdir]
    if not files: raise RuntimeError('Build folder is empty.')
    # Construct a flat directory/file table preserving relative folders.
    class E:
        def __init__(self,typ,name,parent=None): self.typ=typ; self.name=name; self.parent=parent; self.children=[]; self.data=None; self.path=None; self.index=0
    root_e=E('dir',''); dirs={'':root_e}
    for p in sorted(files,key=lambda x:x.relative_to(root).as_posix().lower()):
        rel=p.relative_to(root).as_posix(); parts=rel.split('/'); cur=''; parent=root_e
        for part in parts[:-1]:
            cur=f'{cur}/{part}'.strip('/')
            if cur not in dirs:
                d=E('dir',part,parent); parent.children.append(d); dirs[cur]=d
            parent=dirs[cur]
        f=E('file',parts[-1],parent); f.path=p; parent.children.append(f)
    entries=[]
    def flatten(d):
        d.index=len(entries); entries.append(d)
        # directories first, then files, deterministic
        for c in sorted(d.children,key=lambda x:(x.typ!='dir',x.name.lower())): flatten(c)
    flatten(root_e)
    for i,e in enumerate(entries): e.index=i
    names=bytearray(b'\0'); name_off={}
    for e in entries:
        if e.name and e.name not in name_off:
            name_off[e.name]=len(names); names.extend(e.name.encode('utf-8','replace')+b'\0')
    # entry ranges are contiguous due to flattening, compute child spans
    def span(d):
        if not d.children:return (d.index+1,0)
        return (d.children[0].index,len_subtree(d))
    def len_subtree(d):
        n=0
        def count(x):
            nonlocal n
            for c in x.children: n+=1; count(c) if c.typ=='dir' else None
        count(d); return n
    import struct
    table=bytearray(); payload=bytearray(); sector=1
    for e in entries:
        if e.typ=='dir':
            idx,cnt=span(e); table.extend(struct.pack('<II',name_off.get(e.name,0),0x7fffff00)); table.extend(struct.pack('<II',idx,cnt))
        else:
            data=e.path.read_bytes(); pad=(512-(len(payload)%512))%512; payload.extend(b'\0'*pad); sector=1+len(payload)//512; # sector of data starts after table, corrected below
            table.extend(struct.pack('<H',name_off[e.name])); table.extend(bytes([len(data)&255,(len(data)>>8)&255,(len(data)>>16)&255])); table.extend(struct.pack('<I',0)); table.extend(struct.pack('<II',len(data),0))
            e.data=data
    header_len=16+len(table)+len(names); data_start=(header_len+511)//512*512; first_sector=data_start//512
    # patch file sectors in table by re-walking entries
    off=0; payload=bytearray();
    for e in entries:
        if e.typ=='file':
            pad=(512-(len(payload)%512))%512; payload.extend(b'\0'*pad); sec=first_sector+len(payload)//512; payload.extend(e.data)
            table[off+5:off+8]=bytes([sec&255,(sec>>8)&255,(sec>>16)&255]); off+=16
        else: off+=16
    out=outdir/(root.name+'.rpf')
    with open(out,'wb') as f:
        f.write(struct.pack('<IIII',0x52504637,len(entries),len(names),0x4e45504f)); f.write(table); f.write(names); f.write(b'\0'*(data_start-(16+len(table)+len(names)))); f.write(payload)
    return {'operation':'build_rpf','output':str(out.relative_to(root)),'files':len(files)}

def smart(root, mode='keep'):
    root=Path(root); work=Path(tempfile.mkdtemp(prefix='samssz_mobile_smart_')); generated=[]; sources=[]; report=[]
    try:
        loose=[p for p in _files(root) if p.suffix.lower() in MODEL_EXTS or p.suffix.lower()=='.ytd']
        # Direct loose resources.
        for p in loose:
            ext=p.suffix.lower()
            try:
                if ext in MODEL_EXTS:
                    direction='pc2ps4' if ext in PC_EXTS else 'ps42pc'
                    if _convert_file(p,direction):
                        out=p.with_suffix((PC_TO_PS4[ext] if ext in PC_TO_PS4 else PS4_TO_PC[ext])['out'])
                        generated.append(out); sources.append(p)
                elif ext=='.ytd':
                    # Exact Python extractor stage. OTD build still depends on RageBuilder runtime.
                    d=p.with_suffix(''); sc.YTD_ENGINE['extract_ytd'](str(p),str(d)); sources.append(p)
            except Exception as e: report.append({'file':str(p.relative_to(root)),'error':str(e)})
        # Entry RPFs.
        for rpf in _target_rpfs(root):
            tw=work/(f'rpf_{abs(hash(str(rpf)))%1000000000}'); tw.mkdir(parents=True,exist_ok=True)
            try:
                extract_rpf_one(rpf,tw)
                for p in [p for p in _files(tw) if p.suffix.lower() in PC_EXTS]:
                    if _convert_file(p,'pc2ps4'): generated.append(p)
                sources.append(rpf)
            except Exception as e: report.append({'rpf':str(rpf.relative_to(root)),'error':str(e)})
        # Publish converted files preserving family folders.
        outdir=root/'Samssz_Converted'; outdir.mkdir(exist_ok=True)
        published=[]
        for p in generated:
            if not p.is_file(): continue
            fam=sc._smart_model_base(p.stem)
            fd=outdir/fam; fd.mkdir(parents=True,exist_ok=True)
            dst=fd/p.name
            shutil.copy2(p,dst); published.append(dst)
        # Mode 3/4 package each family; mode 4 purges source only.
        zips=[]
        if mode in ('zipask','purge'):
            groups={}
            for p in published: groups.setdefault(sc._smart_model_base(p.stem),[]).append(p)
            for fam,items in groups.items():
                z=outdir/f'({fam})NAMA MOD.zip'; sc.smart_zip_family_outputs(items,z,fam); zips.append(z)
        if mode in ('purge','props'):
            for s in sources:
                if s.is_file() and s.suffix.lower() in MODEL_EXTS|{'.ytd','.rpf'}:
                    try:s.unlink()
                    except:pass
        return {'operation':'smart','published':[str(p.relative_to(root)) for p in published], 'zips':[str(z.relative_to(root)) for z in zips], 'sources':[str(s.relative_to(root)) for s in sources if s.exists()], 'purged':mode in ('purge','props'),'report':report}
    finally:
        shutil.rmtree(work,ignore_errors=True)


def _runtime_roots(root):
    roots=[]
    for p in [Path(os.environ.get('SAMSSZ_OTD_RUNTIME','')),Path.home()/'.samssz_otd_runtime',Path(root)/'otd_runtime']:
        if str(p) and p.exists() and p.is_dir() and p not in roots: roots.append(p)
    return roots

def _find_exec(names,roots):
    import shutil as _shutil
    for r in roots:
        for name in names:
            d=r/name
            if d.is_file() and os.access(d,os.X_OK): return d
            for p in r.rglob(name):
                if p.is_file() and os.access(p,os.X_OK): return p
    for name in names:
        q=_shutil.which(name)
        if q: return Path(q)
    return None

def _find_runtime_assets():
    # SamsszConverter extracts its embedded desktop builder payload to a
    # temporary runtime directory during import. Use that exact directory.
    here=Path(getattr(sc,'_RUNTIME_DIR',Path(sc.__file__).resolve().parent))
    names=['ragebuilder.exe','texture_builder.lua','xg.dll','zlib.dll','zlib1.dll']
    return {n:here/n for n in names if (here/n).is_file()}

def build_otd(root):
    root=Path(root); ytds=[p for p in _files(root) if p.suffix.lower()=='.ytd']
    if not ytds: raise RuntimeError('OTD: 0 .YTD detected.')
    assets=_find_runtime_assets(); missing=[n for n in ('ragebuilder.exe','texture_builder.lua','xg.dll','zlib.dll','zlib1.dll') if n not in assets]
    if missing: raise RuntimeError('OTD runtime files missing: '+', '.join(missing))
    roots=_runtime_roots(root); xow=_find_exec(['xow64'],roots); wine=_find_exec(['wine64','wine'],roots)
    if not xow and not wine and platform.system()!='Windows':
        raise RuntimeError('OTD runtime not installed: Android ARM64 needs a working Wine/Box64 runtime in otd_runtime/.')
    # The embedded OTD engine resolves xow64/Wine through HOME/PATH. When a
    # runtime pack is supplied inside the selected workspace, expose that exact
    # runtime without touching the device-wide environment.
    old_home=os.environ.get('HOME'); old_path=os.environ.get('PATH',''); old_runtime=os.environ.get('SAMSSZ_RUNTIME_DIR')
    candidate=roots[0] if roots else None
    if candidate:
        os.environ['HOME']=str(candidate)
        os.environ['SAMSSZ_RUNTIME_DIR']=str(candidate)
        os.environ['PATH']=str(candidate)+os.pathsep+str(candidate/'bin')+os.pathsep+old_path
        if xow:
            try: xow.chmod(xow.stat().st_mode | 0o111)
            except OSError: pass
    outdir=root/'Build'; outdir.mkdir(parents=True,exist_ok=True); built=[]; errors=[]
    for ytd in ytds:
        d=ytd.with_suffix(''); final=outdir/(ytd.stem+'.otd')
        try:
            sc.YTD_ENGINE['extract_ytd'](str(ytd),str(d))
            old=list(sys.argv); sys.argv=['build_otd.py',str(d),str(final)]
            try: rc=sc.OTD_ENGINE['main']()
            finally: sys.argv=old
            if rc!=0 or not final.is_file() or final.stat().st_size<=0: raise RuntimeError(f'RageBuilder returned {rc}; no valid OTD output.')
            built.append(str(final.relative_to(root)))
        except Exception as e: errors.append({'ytd':str(ytd.relative_to(root)),'error':str(e)})
    result={'operation':'build_otd','detected':len(ytds),'success':len(built),'failed':len(errors),'built':built,'errors':errors}
    if old_home is None: os.environ.pop('HOME',None)
    else: os.environ['HOME']=old_home
    os.environ['PATH']=old_path
    if old_runtime is None: os.environ.pop('SAMSSZ_RUNTIME_DIR',None)
    else: os.environ['SAMSSZ_RUNTIME_DIR']=old_runtime
    if errors and not built: raise RuntimeError('OTD builder failed: '+json.dumps(result,ensure_ascii=False))
    return result

def run(root, operation, mode='keep', direction='both'):
    root=Path(root)
    if operation=='convert': return convert_models(root,direction)
    if operation=='extract': return extract_all(root)
    if operation=='auto_scan': return auto_scan(root)
    if operation=='smart': return smart(root,mode)
    if operation=='pipeline':
        # Full vehicle pipeline: extract entry RPF/YTD first, then convert supported resources.
        ex=extract_all(root)
        sm=smart(root,'keep')
        return {'operation':'pipeline','extract':ex,'smart':sm}
    if operation=='build_rpf': return build_rpf(root)
    if operation=='build_otd': return build_otd(root)
    raise ValueError('Unknown operation: '+operation)

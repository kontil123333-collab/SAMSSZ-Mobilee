#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import zipfile
from pathlib import Path

RESET='\033[0m'; BRIGHT='\033[1m'; CYAN='\033[96m'; GREEN='\033[92m'
YELLOW='\033[93m'; RED='\033[91m'; MAGENTA='\033[95m'; WHITE='\033[97m'


def header():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(CYAN+'═'*58+RESET)
    print(BRIGHT+MAGENTA+'          SAMSSZ • BATCH FILE RENAMER'+RESET)
    print(CYAN+'        OFT / OTD + ZIP FAMILY RENAME TOOL'+RESET)
    print(CYAN+'═'*58+RESET)
    print(WHITE+'Sekali rename → OFT/OTD + isi ZIP + nama ZIP ikut berubah.'+RESET)
    print()


def family_root(stem):
    s = stem
    for suffix in ('_hi', '+hi'):
        if s.lower().endswith(suffix.lower()):
            return s[:-len(suffix)]
    return s


def is_convert_file(p):
    return p.is_file() and p.suffix.lower() in ('.oft', '.otd')


def find_family(folder, old_name):
    result = []
    for p in folder.iterdir():
        if is_convert_file(p):
            root = family_root(p.stem)
            if p.stem == old_name or root == old_name:
                result.append(p)
    return sorted(result, key=lambda x: x.name.lower())


def zip_matches(p, old_name):
    s = p.stem
    return s in (old_name, f'({old_name})', f'{old_name}NAMA MOD', f'({old_name})NAMA MOD')


def rename_zip_contents(zip_path, old_name, new_name):
    """Rename OFT/OTD family inside ZIP, preserving other files/folders."""
    tmp = zip_path.with_name(f'.samssz_zip_tmp_{os.getpid()}.zip')
    try:
        with zipfile.ZipFile(zip_path, 'r') as zin, zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as zout:
            for info in zin.infolist():
                arc = info.filename
                parts = arc.rsplit('/', 1)
                dirname = parts[0] + '/' if len(parts) == 2 else ''
                basename = parts[-1]
                q = Path(basename)
                if q.suffix.lower() in ('.oft', '.otd'):
                    root = family_root(q.stem)
                    if q.stem == old_name or root == old_name:
                        tail = q.stem[len(root):] if q.stem != root else ''
                        basename = new_name + tail + q.suffix.lower()
                        arc = dirname + basename
                data = zin.read(info.filename)
                ni = zipfile.ZipInfo(arc, info.date_time)
                ni.compress_type = zipfile.ZIP_DEFLATED
                ni.comment = info.comment
                ni.extra = info.extra
                ni.create_system = info.create_system
                ni.external_attr = info.external_attr
                zout.writestr(ni, data)
        tmp.replace(zip_path)
    except Exception:
        try: tmp.unlink(missing_ok=True)
        except Exception: pass
        raise


def rename_zip(zip_path, old_name, new_name):
    rename_zip_contents(zip_path, old_name, new_name)
    # FINAL FORMAT: (NAMA_BARU)NAMA_LAMA.zip
    target = zip_path.with_name(f'({new_name}){old_name}.zip')
    if target != zip_path:
        if target.exists():
            raise FileExistsError(f'ZIP tujuan sudah ada: {target.name}')
        zip_path.rename(target)
    return target


def main():
    header()
    folder = Path(sys.argv[1] if len(sys.argv) > 1 else '.').expanduser().resolve()
    if not folder.is_dir():
        print(RED+f'[ERROR] Folder tidak ditemukan: {folder}'+RESET)
        input('\nENTER untuk keluar...')
        return 1

    print(CYAN+f'FOLDER : {folder}'+RESET)
    old_name = input(YELLOW+'Nama lama (contoh car1) : '+RESET).strip()
    if not old_name:
        print(RED+'Nama lama tidak boleh kosong.'+RESET); input('\nENTER untuk keluar...'); return 1

    files = find_family(folder, old_name)
    if not files:
        print(RED+'\n[ERROR] Tidak ditemukan .oft/.otd family tersebut.'+RESET)
        input('\nENTER untuk keluar...'); return 1

    print('\n'+BRIGHT+CYAN+'FILE TERDETEKSI:'+RESET)
    for p in files: print(GREEN+f'  • {p.name}'+RESET)

    new_name = input('\n'+YELLOW+'Nama baru (contoh avanza) : '+RESET).strip()
    if not new_name or any(c in new_name for c in ('/', '\\', '\0')):
        print(RED+'Nama baru tidak valid.'+RESET); input('\nENTER untuk keluar...'); return 1

    zips = [p for p in folder.iterdir() if p.is_file() and p.suffix.lower()=='.zip' and zip_matches(p, old_name)]

    print('\n'+BRIGHT+MAGENTA+'PREVIEW:'+RESET)
    for src in files:
        root = family_root(src.stem)
        tail = src.stem[len(root):] if src.stem != root else ''
        print(WHITE+f'  {src.name:<28} → '+GREEN+new_name+tail+src.suffix.lower()+RESET)
    for zp in zips:
        print(WHITE+f'  {zp.name:<28} → '+GREEN+f'({new_name}){old_name}.zip'+RESET)
        print(CYAN+'    ↳ isi OFT/OTD di dalam ZIP juga ikut rename'+RESET)

    confirm = input('\n'+YELLOW+'Lanjut rename semuanya? [Y/N] : '+RESET).strip().lower()
    if confirm not in ('y','yes','ya','iya'):
        print(CYAN+'Dibatalkan.'+RESET); input('\nENTER untuk keluar...'); return 0

    plan=[]
    sources={p.resolve() for p in files}
    for src in files:
        root=family_root(src.stem); tail=src.stem[len(root):] if src.stem != root else ''
        dst=src.with_name(new_name+tail+src.suffix.lower())
        if dst.exists() and dst.resolve() not in sources:
            print(RED+f'[ERROR] File tujuan sudah ada: {dst.name}'+RESET); input('\nENTER untuk keluar...'); return 1
        plan.append((src,dst))

    try:
        temps=[]
        for i,(src,dst) in enumerate(plan):
            tmp=src.with_name(f'.samssz_rename_tmp_{os.getpid()}_{i}{src.suffix}')
            src.rename(tmp); temps.append((tmp,dst))
        for tmp,dst in temps: tmp.rename(dst)

        for zp in zips:
            nz=rename_zip(zp, old_name, new_name)
            print(GREEN+f'  ZIP OK: {nz.name}'+RESET)

        print(CYAN+'═'*58+RESET)
        print(BRIGHT+GREEN+'✓ RENAME BERHASIL'+RESET)
        print(GREEN+f'{len(files)} file OFT/OTD berhasil diubah.'+RESET)
        if zips: print(GREEN+f'{len(zips)} ZIP ikut diperbarui.'+RESET)
        print(CYAN+'═'*58+RESET)
    except Exception as e:
        print(RED+f'\n[ERROR] {e}'+RESET)
        return 1
    finally:
        input('\nENTER untuk keluar...')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

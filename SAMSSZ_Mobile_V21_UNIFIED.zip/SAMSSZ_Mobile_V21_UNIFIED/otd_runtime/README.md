# SAMSSZ Full OTD Runtime

Put the complete Android ARM64-compatible runtime in this directory. The converter calls the original `OTD_ENGINE` from `SamsszConverter.py`; it does not replace RageBuilder with a fake builder.

Expected executable/runtime entry point:
- `xow64` (preferred), or `wine`/`wine64`

The runtime must include its Wine prefix and all libraries required by the chosen runtime. The app exposes `HOME`, `PATH`, and `SAMSSZ_RUNTIME_DIR` to the runtime while building, so the original embedded OTD builder can resolve `ragebuilder.exe`, `texture_builder.lua`, and its DLLs.

The builder only counts `.YTD` inputs that are actual files in the selected workspace and only reports success after a non-empty `.OTD` file exists in `Build/`.

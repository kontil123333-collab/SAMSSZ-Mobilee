# SAMSSZ Mobile

Android Studio project for a native mobile front-end based on the supplied `SamsszConverter.py`.

## What is implemented

- Neon/dark SAMSSZ mobile UI, designed independently from the screenshot supplied by the user.
- SAF folder picker so the app works with Android shared storage without hardcoded paths.
- PC -> PS4 model conversion for `.yft .ydr .ydd .ypt .ybn .ybd .ycd .ymap .ytyp .ymt .ymf`.
- PS4 -> PC conversion for `.oft .odr .odd .opt .obn .obd .ocd .omap .otyp .omt .omf`.
- RSC7 raw-deflate decode/re-encode and the GTAV1 <-> PS4 8-byte patch used by the supplied Python Model Forge.
- Recursive folder scan.
- ZIP archive scan for supported loose model resources.
- Safe duplicate output names: `(1)`, `(2)`, ...
- All 11 menu entries from the supplied toolkit are represented in the mobile UI.
- The original `SamsszConverter.py` is bundled in `app/src/main/assets/` for reference.

## Android-specific limitation

The supplied Python tool's RPF/OTD build path calls `ragebuilder.exe` and uses Windows/Wine/xow64. A normal Android APK cannot truthfully claim that Windows executable runtime as a native Android engine. Therefore menu 4 and menu 5 are exposed but explicitly marked as desktop-runtime-dependent instead of silently failing or pretending to work.

## Build

Open this folder in a recent Android Studio release and build the `app` module. The project uses Android Gradle Plugin 8.6.0 and `compileSdk 35`.

Package name: `com.samssz.mobile`
App name: `SAMSSZ Mobile`

## APK build helper

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml` to compile `app-debug.apk` remotely. See `BUILD_APK.md`.

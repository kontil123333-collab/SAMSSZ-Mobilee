package com.samssz.mobile;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** SAMSSZ Mobile — modern native Android front-end for SamsszConverter.py. */
public class MainActivity extends Activity {
    private static final int PICK_TREE = 1001;
    private Uri selectedTree;
    private TextView pathLabel;
    private TextView logView;
    private LinearLayout content;
    private ProgressBar processBar;
    private TextView processStatus;
    private TextView processPercent;
    private TextView processConsole;
    private TextView processCode;
    private boolean showProcessCode=false;
    private SharedPreferences prefs;
    private static final int BG=0xFF090616, SURFACE=0xFF14102A, SURFACE2=0xFF1B1538;
    private static final int PURPLE=0xFF9A4DFF, VIOLET=0xFF6D35FF, CYAN=0xFF5DE7FF;
    private static final int WHITE=0xFFF7F4FF, MUTED=0xFFA9A2C4, GREEN=0xFF5CFFB0, RED=0xFFFF6F91;

    private static final Map<String,String> PC_TO_PS4 = new LinkedHashMap<>();
    private static final Map<String,String> PS4_TO_PC = new LinkedHashMap<>();
    private static final Set<String> PATCH_EXTS = new HashSet<>();
    static {
        addPair(".yft", ".oft", true); addPair(".ydr", ".odr", true); addPair(".ydd", ".odd", true);
        addPair(".ypt", ".opt", true); addPair(".ybn", ".obn", true); addPair(".ybd", ".obd", true);
        addPair(".ycd", ".ocd", false); addPair(".ymap", ".omap", false); addPair(".ytyp", ".otyp", false);
        addPair(".ymt", ".omt", false); addPair(".ymf", ".omf", false);
    }
    private static void addPair(String pc,String ps4,boolean patch){ PC_TO_PS4.put(pc,ps4); PS4_TO_PC.put(ps4,pc); if(patch) PATCH_EXTS.add(pc); }

    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("samssz",MODE_PRIVATE); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); buildUi(); }
    private int dp(float v){ return Math.round(v*getResources().getDisplayMetrics().density); }
    private TextView tv(String s,float sp,int c,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(c); t.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL)); t.setIncludeFontPadding(false); return t; }
    private TextView neonText(String s,float sp,int c){ TextView t=tv(s,sp,c,true); t.setLayerType(View.LAYER_TYPE_SOFTWARE,null); t.setShadowLayer(dp(9),0,0,0xCC8A3DFF); return t; }
    private View spacer(int h){ View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h))); return v; }
    private android.graphics.drawable.GradientDrawable bg(int color,float radius,int stroke,int strokeColor){ android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); if(stroke>0)g.setStroke(dp(stroke),strokeColor); return g; }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(16),dp(18),dp(16),dp(28)); scroll.addView(content); setContentView(scroll);
        home();
    }
    private void clearPage(){ content.removeAllViews(); }
    private void titleBar(String title,String subtitle){
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,0,0,dp(10));
        TextView back=button("‹",SURFACE2,WHITE); back.setTextSize(28); back.setOnClickListener(v->home()); row.addView(back,new LinearLayout.LayoutParams(dp(48),dp(46)));
        LinearLayout tt=new LinearLayout(this); tt.setOrientation(LinearLayout.VERTICAL); tt.setPadding(dp(12),0,0,0); tt.addView(tv(title,22,WHITE,true)); tt.addView(tv(subtitle,11,MUTED,false)); row.addView(tt,new LinearLayout.LayoutParams(0,-2,1)); content.addView(row);
    }
    private TextView button(String label,int color,int textColor){ TextView b=tv(label,13,textColor,true); b.setGravity(Gravity.CENTER); b.setPadding(dp(12),dp(11),dp(12),dp(11)); b.setBackground(bg(color,14,1,0xFF6F35D8)); b.setLayerType(View.LAYER_TYPE_SOFTWARE,null); b.setShadowLayer(dp(7),0,0,0x884B18FF); return b; }
    private LinearLayout card(){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(14),dp(14),dp(14),dp(14)); c.setBackground(bg(SURFACE,18,1,0xFF5A35A0)); c.setLayerType(View.LAYER_TYPE_SOFTWARE,null); c.setElevation(dp(2)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(10); c.setLayoutParams(p); return c; }
    private void addCardButton(String no,String title,String desc,View.OnClickListener click){
        LinearLayout c=card(); LinearLayout h=new LinearLayout(this); h.setGravity(Gravity.CENTER_VERTICAL);
        TextView n=button(no,VIOLET,WHITE); n.setTextSize(12); h.addView(n,new LinearLayout.LayoutParams(dp(40),dp(38)));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(11),0,dp(7),0); tx.addView(tv(title,14,WHITE,true)); tx.addView(tv(desc,11,MUTED,false)); h.addView(tx,new LinearLayout.LayoutParams(0,-2,1));
        TextView go=button("›",SURFACE2,CYAN); go.setOnClickListener(click); h.addView(go,new LinearLayout.LayoutParams(dp(45),dp(40))); c.addView(h); content.addView(c);
    }
    private void home(){
        clearPage();
        ImageView logo=new ImageView(this); logo.setImageResource(com.samssz.mobile.R.drawable.ic_launcher); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); logo.setAdjustViewBounds(true); content.addView(logo,new LinearLayout.LayoutParams(-1,dp(190)));
        TextView brand=neonText("SAMSSZ",40,WHITE); brand.setGravity(Gravity.CENTER); content.addView(brand,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView sub=neonText("MOBILE TOOLKIT  •  MODDING MADE EASIER",11,CYAN); sub.setGravity(Gravity.CENTER); content.addView(sub,new LinearLayout.LayoutParams(-1,dp(24)));
        content.addView(spacer(10));
        LinearLayout hero=card(); TextView ht=tv("MODDER • TODAY",18,WHITE,true); hero.addView(ht); hero.addView(tv("PC ↔ PS4 resource tools\nModern UI • local history • AI assistant",12,MUTED,false)); content.addView(hero);
        addCardButton("1","SMART MOD BUILDER","5 workflow choices seperti menu Python asli",v->smartMenu());
        addCardButton("2","FULL VEHICLE PIPELINE","DLC / RPF vehicle workflow",v->unsupported("Full RPF vehicle pipeline masih membutuhkan engine desktop."));
        addCardButton("3","AUTO SCAN CONVERT","Recursive folder + ZIP + model conversion",v->runAutoScan());
        addCardButton("4","EXTRACT • RPF / YTD","Native Android bridge status",v->unsupported("RPF/YTD extract penuh masih membutuhkan runtime desktop/xow64."));
        addCardButton("5","BUILD • RPF / OTD","Build output → Samssz_Converted / Build",v->unsupported("RPF/OTD build penuh membutuhkan RageBuilder runtime."));
        addCardButton("6","CONVERT TO PC","PS4 OFT/ODR/... → PC YFT/YDR/...",v->runSmart(true));
        addCardButton("7","SAMSSZ AI","OFFLINE atau ONLINE • tutorial • auto-save code",v->aiModeMenu());
        addCardButton("8","QUICK HELP","Penjelasan semua menu",v->showHelp());
        addCardButton("9","SYSTEM INFO","Version dan supported formats",v->showSystemInfo());
        addCardButton("10","CHANGE LOG","Versi mobile dan UI",v->showChangelog());
        addCardButton("11","EXIT","Tutup aplikasi",v->finish());
        content.addView(spacer(4));
        LinearLayout work=card(); work.addView(tv("WORKSPACE",11,PURPLE,true)); pathLabel=tv(selectedTree==null?"Belum ada folder dipilih":"Folder siap ✓",12,MUTED,false); pathLabel.setPadding(0,dp(7),0,dp(9)); work.addView(pathLabel); TextView pick=button("PILIH FOLDER",VIOLET,WHITE); pick.setOnClickListener(v->chooseFolder()); work.addView(pick); content.addView(work);
        LinearLayout log=card(); log.addView(tv("ACTIVITY",11,PURPLE,true)); logView=tv("Ready. Pilih folder untuk mulai.",12,WHITE,false); logView.setPadding(0,dp(7),0,0); log.addView(logView); content.addView(log);
    }
    private void smartMenu(){
        clearPage(); titleBar("Smart Mod Builder","Pilihan mengikuti menu SMART asli dari SamsszConverter.py");
        addCardButton("1","SIMPAN SEMUA • TANPA ZIP","YFT/YTD + hasil konversi disimpan; temporary extract dibersihkan",v->runSmartWorkflow("keep"));
        addCardButton("2","TANYA SETIAP PROSES","Cleanup ditanyakan per proses; versi mobile menyimpan hasil",v->runSmartWorkflow("ask"));
        addCardButton("3","ZIP + TANYA SEKALI","Workflow ZIP lalu satu keputusan cleanup",v->runSmartWorkflow("auto"));
        addCardButton("4","AUTO ZIP + PURGE","ZIP otomatis; file lama dihapus setelah sukses",v->runSmartWorkflow("purge"));
        addCardButton("5","PROPS + STRUCTURE • AUTO PURGE","Mode struktur/props tanpa ZIP",v->runSmartWorkflow("props"));
        LinearLayout c=card(); c.addView(tv("Catatan",12,PURPLE,true)); c.addView(tv("Pilihan di atas mempertahankan konsep 5 mode dari Python. Konversi Android saat ini memakai matrix model PC ↔ PS4 yang sudah ada.",12,MUTED,false)); content.addView(c);
    }
    private void runSmartWorkflow(String mode){
        String label;
        if("keep".equals(mode)) label="Mode 1 • Simpan semua • tanpa ZIP";
        else if("ask".equals(mode)) label="Mode 2 • Tanya setiap proses";
        else if("auto".equals(mode)) label="Mode 3 • ZIP + tanya sekali";
        else if("purge".equals(mode)) label="Mode 4 • Auto ZIP + purge";
        else label="Mode 5 • Props + Structure";
        startProcessScreen(label);
        requireFolder(() -> runSmart(false));
    }

    private void aiModeMenu(){ clearPage(); titleBar("SAMSSZ AI","Pilih satu dari dua mode"); addCardButton("ON","ONLINE AI + TUTORIAL","Butuh internet + API key provider OpenAI-compatible",v->onlineAi()); addCardButton("OFF","OFFLINE AI","Rule-based local assistant • tanpa internet",v->offlineAi()); LinearLayout c=card(); c.addView(tv("AUTO-SAVE CODE",12,PURPLE,true)); c.addView(tv("Setiap code yang kamu simpan dari AI otomatis masuk ke penyimpanan lokal dan bisa dibuka lagi.",12,MUTED,false)); content.addView(c); }

    private EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(0xFF766F91); e.setTextColor(WHITE); e.setTextSize(13); e.setPadding(dp(12),dp(10),dp(12),dp(10)); e.setBackground(bg(SURFACE2,14,1,0xFF422A78)); return e; }
    private void offlineAi(){ clearPage(); titleBar("SAMSSZ AI • OFFLINE","Local assistant • tidak memakai internet");
        LinearLayout intro=card(); intro.addView(tv("OFFLINE MODE",16,WHITE,true)); intro.addView(tv("Bisa bantu tentang GTA V modding, format YFT/YDR/YTD/OTD/OFT, workflow converter, dan error umum. Jawaban rule-based sehingga tetap tersedia tanpa koneksi.",12,MUTED,false)); content.addView(intro);
        String[] topics={"GTA V MODDING","CONVERTER","RPF / YTD","SCRIPTING","ERROR"}; LinearLayout chips=new LinearLayout(this); chips.setPadding(0,0,0,dp(8)); for(String s:topics){ TextView c=button(s,SURFACE2,PURPLE); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(40),1); p.setMargins(dp(2),0,dp(2),0); chips.addView(c,p); c.setOnClickListener(v->offlineAnswer(s)); } content.addView(chips);
        EditText q=input("Tulis pertanyaan..."); content.addView(q,new LinearLayout.LayoutParams(-1,dp(90))); TextView ask=button("TANYA OFFLINE",VIOLET,WHITE); ask.setOnClickListener(v->{String x=q.getText().toString().trim(); if(!x.isEmpty()){String a=offlineAnswerText(x); addAiBubble(x,a); autoSaveCode(a);}}); content.addView(ask); EditText code=input("Tempel code di sini • otomatis disimpan saat tombol ditekan"); content.addView(code,new LinearLayout.LayoutParams(-1,dp(130))); TextView save=button("SIMPAN CODE OTOMATIS",SURFACE2,CYAN); save.setOnClickListener(v->{String x=code.getText().toString().trim(); if(!x.isEmpty()) saveCode(x);}); content.addView(save); savedCodesCard(); }
    private String offlineAnswerText(String q){ String l=q.toLowerCase(Locale.ROOT); if(l.contains("yft")||l.contains("oft")) return "YFT adalah resource model PC dan OFT pasangan PS4. SAMSSZ memakai matrix PC→PS4 untuk konversi resource yang didukung.\n\nTips: jangan hapus file asli sebelum hasil berhasil diverifikasi."; if(l.contains("ytd")||l.contains("otd")) return "YTD adalah texture dictionary PC. Workflow Python SAMSSZ memasukkan YTD ke pipeline DDS lalu OTD. Pada Android port, build OTD native masih ditandai membutuhkan runtime desktop."; if(l.contains("rpf")) return "Untuk RPF, cek apakah input berisi vehicles.rpf atau dlc.rpf. Smart workflow Python memprioritaskan vehicles.rpf lalu DLC variants."; if(l.contains("error")||l.contains("gagal")) return "Kirim pesan error lengkap + nama file yang diproses. Mulai dari mengecek ekstensi, path input, permission folder, lalu pastikan hasil tidak tertukar dengan file lama."; return "SAMSSZ AI OFFLINE: coba tanyakan tentang Smart Mod Builder, konversi PC↔PS4, YTD→OTD, RPF, ZIP, atau error converter."; }
    private String offlineAnswer(String topic){ String a=offlineAnswerText(topic); addAiBubble(topic,a); return a; }
    private void addAiBubble(String q,String a){ LinearLayout c=card(); c.addView(tv("KAMU",11,PURPLE,true)); c.addView(tv(q,13,WHITE,false)); c.addView(tv("SAMSSZ AI",11,CYAN,true)); c.addView(tv(a,13,WHITE,false)); content.addView(c); }
    private void autoSaveCode(String text){ int start=text.indexOf("```"); if(start>=0){int end=text.indexOf("```",start+3); if(end>start){String code=text.substring(start+3,end).replaceFirst("^[a-zA-Z0-9_+-]+\\n","").trim(); if(!code.isEmpty()) saveCode(code);}} }
    private void saveCode(String code){ String old=prefs.getString("codes",""); try{JSONArray arr=old.isEmpty()?new JSONArray():new JSONArray(old); JSONObject o=new JSONObject(); o.put("code",code); o.put("time",System.currentTimeMillis()); arr.put(o); prefs.edit().putString("codes",arr.toString()).apply(); Toast.makeText(this,"Code otomatis tersimpan ✓",Toast.LENGTH_SHORT).show();}catch(Exception ignored){} }
    private void savedCodesCard(){ LinearLayout c=card(); c.addView(tv("SAVED CODE",12,PURPLE,true)); try{JSONArray a=new JSONArray(prefs.getString("codes","[]")); if(a.length()==0)c.addView(tv("Belum ada code tersimpan.",12,MUTED,false)); for(int i=Math.max(0,a.length()-5);i<a.length();i++){JSONObject o=a.getJSONObject(i); TextView t=button("CODE "+(i+1),SURFACE2,WHITE); String code=o.optString("code"); t.setOnClickListener(v->{EditText e=input("Code"); e.setText(code); e.setSelectAllOnFocus(true); content.addView(e,new LinearLayout.LayoutParams(-1,dp(160)));}); c.addView(t);} }catch(Exception ignored){} content.addView(c); }

    private void onlineAi(){ clearPage(); titleBar("SAMSSZ AI • ONLINE","AI + tutorial • code otomatis disimpan jika ada code block");
        LinearLayout tutorial=card(); tutorial.addView(tv("TUTORIAL CEPAT",15,WHITE,true)); tutorial.addView(tv("1. Masukkan API key provider OpenAI-compatible.\n2. Pilih endpoint dan model.\n3. Tulis pertanyaan.\n4. Jawaban code yang memakai ``` akan otomatis disimpan.\n5. Koneksi gagal → mode offline tetap bisa dipakai dari menu AI.",12,MUTED,false)); content.addView(tutorial);
        EditText endpoint=input("Endpoint (contoh: https://openrouter.ai/api/v1/chat/completions)"); endpoint.setText(prefs.getString("endpoint","https://openrouter.ai/api/v1/chat/completions")); content.addView(endpoint);
        EditText model=input("Model (contoh: openrouter/free)"); model.setText(prefs.getString("model","openrouter/free")); content.addView(model);
        EditText key=input("API key"); key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); key.setText(prefs.getString("key","")); content.addView(key);
        EditText q=input("Tulis pertanyaan untuk AI online..."); content.addView(q,new LinearLayout.LayoutParams(-1,dp(90)));
        TextView ask=button("KIRIM KE ONLINE AI",VIOLET,WHITE); ask.setOnClickListener(v->{prefs.edit().putString("endpoint",endpoint.getText().toString().trim()).putString("model",model.getText().toString().trim()).putString("key",key.getText().toString().trim()).apply(); String question=q.getText().toString().trim(); if(question.isEmpty())return; addAiBubble(question,"⏳ Menghubungi provider online..."); ask.setEnabled(false); ask.setText("MEMPROSES...  ⟳"); new Thread(()->{String answer=onlineRequest(question); runOnUiThread(()->{addAiBubble("ONLINE RESULT",answer); autoSaveCode(answer); ask.setEnabled(true); ask.setText("KIRIM KE ONLINE AI");});}).start();}); content.addView(ask); EditText code=input("Tempel code di sini • otomatis disimpan saat tombol ditekan"); content.addView(code,new LinearLayout.LayoutParams(-1,dp(130))); TextView save=button("SIMPAN CODE OTOMATIS",SURFACE2,CYAN); save.setOnClickListener(v->{String x=code.getText().toString().trim(); if(!x.isEmpty()) saveCode(x);}); content.addView(save); savedCodesCard(); }
    private String onlineRequest(String q){ String endpoint=prefs.getString("endpoint","").trim(), model=prefs.getString("model","openrouter/free").trim(), key=prefs.getString("key","").trim(); if(endpoint.isEmpty()||key.isEmpty()) return "ONLINE ERROR: isi endpoint dan API key dulu."; try{JSONObject body=new JSONObject(); body.put("model",model); JSONArray msgs=new JSONArray(); JSONObject sys=new JSONObject(); sys.put("role","system"); sys.put("content","Kamu adalah SAMSSZ AI untuk GTA V modding. Beri tutorial langkah demi langkah, contoh aman, dan code bila diperlukan. Jika memberi code, gunakan fenced code block."); msgs.put(sys); JSONObject user=new JSONObject(); user.put("role","user"); user.put("content",q); msgs.put(user); body.put("messages",msgs); body.put("temperature",0.6); HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection(); c.setConnectTimeout(15000); c.setReadTimeout(60000); c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Authorization","Bearer "+key); OutputStreamWriter w=new OutputStreamWriter(c.getOutputStream(),StandardCharsets.UTF_8); w.write(body.toString()); w.close(); InputStream in=c.getResponseCode()<400?c.getInputStream():c.getErrorStream(); BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8)); StringBuilder sb=new StringBuilder(); String line; while((line=r.readLine())!=null)sb.append(line); r.close(); JSONObject out=new JSONObject(sb.toString()); JSONArray choices=out.optJSONArray("choices"); if(choices!=null&&choices.length()>0)return choices.getJSONObject(0).optJSONObject("message").optString("content","Provider tidak mengembalikan content."); return "ONLINE ERROR: "+sb.substring(0,Math.min(700,sb.length())); }catch(Exception e){return "ONLINE ERROR: "+e.getClass().getSimpleName()+" • "+e.getMessage();} }

    private void showHelp(){ clearPage(); titleBar("QUICK HELP","Ringkasan menu SAMSSZ Mobile"); String[] a={"1 Smart Mod Builder → 5 mode dari Python asli.","2 Full Vehicle Pipeline → status runtime desktop.","3 Auto Scan → folder + ZIP + model conversion.","4 Extract → RPF/YTD desktop runtime.","5 Build → RPF/OTD desktop runtime.","6 Convert to PC → PS4 model ke PC.","7 SAMSSZ AI → Offline atau Online.","8 Quick Help → halaman ini.","9 System Info → engine/status.","10 Change Log → versi mobile.","11 Exit → keluar."}; for(String s:a){LinearLayout c=card(); c.addView(tv(s,13,WHITE,false)); content.addView(c);} }
    private void showSystemInfo(){ clearPage(); titleBar("SYSTEM INFO","SAMSSZ Mobile"); LinearLayout c=card(); c.addView(tv("VERSION 2.0 MOBILE",16,WHITE,true)); c.addView(tv("Modern purple UI • Smart menu 1 • AI Offline/Online • local code history • PC↔PS4 model matrix",12,MUTED,false)); content.addView(c); }
    private void showChangelog(){ clearPage(); titleBar("CHANGE LOG","Modern mobile redesign"); LinearLayout c=card(); c.addView(tv("• Modern SAMSSZ branding\n• Purple/blue neon theme\n• Menu 1 now mirrors 5 Smart Builder modes\n• AI reduced to 2 clear modes\n• Online tutorial + provider settings\n• Code snippets auto-saved locally\n• Existing conversion engine retained",13,WHITE,false)); content.addView(c); }
    private void chooseFolder(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,PICK_TREE); }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==PICK_TREE&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){selectedTree=data.getData(); int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION); try{getContentResolver().takePersistableUriPermission(selectedTree,flags);}catch(Exception ignored){} if(pathLabel!=null)pathLabel.setText("Folder dipilih ✓"); log("Workspace siap: "+selectedTree);}}
    private void unsupported(String msg){Toast.makeText(this,msg,Toast.LENGTH_LONG).show(); log("INFO: "+msg);}
    private void log(String s){runOnUiThread(()->{if(logView!=null)logView.setText(s);});}

    private void requireFolder(Runnable r) {
        if (selectedTree == null) { Toast.makeText(this, "Pilih folder dulu.", Toast.LENGTH_SHORT).show(); return; }
        new Thread(() -> { try { r.run(); } catch (Throwable e) { log("ERROR: " + e.getMessage()); } }).start();
    }

    private void runSmart(boolean pcOnly) {
        if (selectedTree == null) { finishProcess(false,"Pilih folder dulu."); return; }
        new Thread(() -> {
            try {
                List<DocumentNode> files = listTree(selectedTree);
                int success=0, fail=0, found=0, total=files.size(), done=0;
                processUpdate(5,"Scanning folder...", "List files → detect supported formats");
                for (DocumentNode n : files) {
                    done++;
                    String lower=n.name.toLowerCase(Locale.ROOT);
                    String ext=extension(lower);
                    boolean accepted = pcOnly ? PS4_TO_PC.containsKey(ext) : (PC_TO_PS4.containsKey(ext) || PS4_TO_PC.containsKey(ext));
                    processUpdate(Math.max(5,Math.min(94,(int)((done*100.0)/Math.max(1,total)))), "Memproses: "+n.name, "READ → PARSE → CONVERT → WRITE");
                    if (!accepted) continue;
                    found++;
                    try {
                        Uri out = createSiblingOutput(selectedTree, n.name, targetExt(ext));
                        byte[] in = readAll(n.uri);
                        byte[] result = ModelConverter.convert(in, ext);
                        writeAll(out, result);
                        success++;
                        processConsoleLine("✓ "+n.name+" → "+targetExt(ext));
                    } catch (Exception e) { fail++; processConsoleLine("✕ "+n.name+" : "+e.getMessage()); }
                }
                finishProcess(true,"DONE • detected="+found+" success="+success+" failed="+fail);
            } catch(Throwable e) { finishProcess(false,"ERROR • "+e.getClass().getSimpleName()+" : "+e.getMessage()); }
        }).start();
    }

    private void runAutoScan() {
        if (selectedTree == null) { Toast.makeText(this,"Pilih folder dulu.",Toast.LENGTH_SHORT).show(); return; }
        startProcessScreen("AUTO SCAN CONVERT");
        new Thread(() -> {
            try {
                List<DocumentNode> files = listTree(selectedTree);
                int supported=0, zip=0, converted=0, done=0;
                for (DocumentNode n: files) {
                    done++; processUpdate(Math.max(4,Math.min(94,(int)((done*100.0)/Math.max(1,files.size())))),"Memeriksa: "+n.name,"SCAN → CHECK EXTENSION → CONVERT");
                    String ext=extension(n.name.toLowerCase(Locale.ROOT));
                    if (PC_TO_PS4.containsKey(ext) || PS4_TO_PC.containsKey(ext)) {
                        supported++;
                        try { Uri out=createOutput(n.name,targetExt(ext)); writeAll(out,ModelConverter.convert(readAll(n.uri),ext)); converted++; processConsoleLine("✓ "+n.name); } catch(Exception e){ processConsoleLine("✕ "+n.name+" : "+e.getMessage()); }
                    } else if (".zip".equals(ext)) { zip++; converted += convertZip(n.uri, n.name); }
                }
                finishProcess(true,"AUTO SCAN • models="+supported+" zip="+zip+" converted="+converted);
            } catch(Throwable e){ finishProcess(false,"ERROR • "+e.getMessage()); }
        }).start();
    }

    private void startProcessScreen(String title){
        runOnUiThread(() -> {
            clearPage(); titleBar("PROCESSING",title);
            LinearLayout hero=card(); hero.setPadding(dp(18),dp(18),dp(18),dp(18));
            TextView h=neonText("SEDANG DIPROSES...",18,WHITE); h.setGravity(Gravity.CENTER); hero.addView(h);
            processPercent=neonText("0%",30,CYAN); processPercent.setGravity(Gravity.CENTER); hero.addView(processPercent,new LinearLayout.LayoutParams(-1,dp(52)));
            processBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); processBar.setMax(100); processBar.setProgress(0); hero.addView(processBar,new LinearLayout.LayoutParams(-1,dp(14)));
            processStatus=tv("Menyiapkan proses...",12,MUTED,true); processStatus.setGravity(Gravity.CENTER); hero.addView(processStatus); content.addView(hero);
            LinearLayout controls=card(); TextView toggle=button("⌘  TAMPILKAN KODE / KODING",SURFACE2,CYAN); toggle.setOnClickListener(v->{showProcessCode=!showProcessCode; if(processCode!=null) processCode.setVisibility(showProcessCode?View.VISIBLE:View.GONE); toggle.setText(showProcessCode?"⌘  SEMBUNYIKAN KODE / KODING":"⌘  TAMPILKAN KODE / KODING");}); controls.addView(toggle); content.addView(controls);
            processConsole=tv("[SAMSSZ] Initializing...",11,0xFFD8D1F5,false); processConsole.setTypeface(Typeface.MONOSPACE); processConsole.setPadding(dp(12),dp(12),dp(12),dp(12)); processConsole.setBackground(bg(0xFF08050F,14,1,0xFF51318D)); LinearLayout console=card(); console.addView(tv("LIVE PROCESS LOG",11,PURPLE,true)); console.addView(processConsole); content.addView(console);
            processCode=tv("// SAMSSZ PROCESS PIPELINE\nscanFolder();\nreadResource();\nconvertResource();\nwriteOutput();\nverifyResult();",11,0xFFB9F8FF,false); processCode.setTypeface(Typeface.MONOSPACE); processCode.setPadding(dp(12),dp(12),dp(12),dp(12)); processCode.setBackground(bg(0xFF050C12,14,1,0xFF246E80)); processCode.setVisibility(View.GONE); LinearLayout code=card(); code.addView(tv("PROCESS CODE / KODING",11,CYAN,true)); code.addView(processCode); content.addView(code);
        });
    }
    private void processUpdate(int percent,String status,String codeLine){
        runOnUiThread(()->{ if(processBar!=null)processBar.setProgress(percent); if(processPercent!=null)processPercent.setText(percent+"%"); if(processStatus!=null)processStatus.setText(status); if(processCode!=null && showProcessCode) processCode.setText("// SAMSSZ PROCESS PIPELINE\n"+codeLine+"\n\nreadResource();\nconvertResource();\nwriteOutput();"); });
    }
    private void processConsoleLine(String line){ runOnUiThread(()->{ if(processConsole==null)return; String old=processConsole.getText().toString(); String[] lines=old.split("\n"); StringBuilder b=new StringBuilder(); int start=Math.max(0,lines.length-14); for(int i=start;i<lines.length;i++) b.append(lines[i]).append('\n'); b.append("[SAMSSZ] ").append(line); processConsole.setText(b.toString()); }); }
    private void finishProcess(boolean ok,String message){ runOnUiThread(()->{ if(processBar!=null)processBar.setProgress(ok?100:0); if(processPercent!=null)processPercent.setText(ok?"100%":"ERR"); if(processStatus!=null)processStatus.setText(message); processConsoleLine(message); }); }
    private void processConsoleLineSafe(String line){ processConsoleLine(line); }

    private String targetExt(String ext) { return PC_TO_PS4.containsKey(ext) ? PC_TO_PS4.get(ext) : PS4_TO_PC.get(ext); }

    private static String extension(String name){ int i=name.lastIndexOf('.'); return i>=0?name.substring(i):""; }

    private static byte[] readAll(Uri uri) throws Exception {
        ContentResolver cr = AppHolder.activity.getContentResolver();
        try(InputStream in=cr.openInputStream(uri); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            if(in==null) throw new Exception("cannot open input");
            byte[] buf=new byte[65536]; int n; while((n=in.read(buf))>=0) out.write(buf,0,n); return out.toByteArray();
        }
    }
    private void writeAll(Uri uri, byte[] data) throws Exception {
        try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){
            if(out==null) throw new Exception("cannot open output"); out.write(data); out.flush();
        }
    }

    private Uri createSiblingOutput(Uri tree, String original, String outExt) throws Exception {
        // Android SAF createDocument() returns a Uri. Keep all converted files
        // inside the app's dedicated output folder, while preserving the
        // original filename and adding a duplicate-safe suffix.
        return createOutput(original, outExt);
    }

    private Uri createOutput(String original, String outExt) throws Exception {
        Uri folder=ensureOutputFolder();
        String base=original; int dot=base.lastIndexOf('.'); if(dot>0) base=base.substring(0,dot);
        String candidate=base+outExt; int i=1;
        while (existsChild(folder,candidate)) candidate=base+" ("+(i++)+")"+outExt;
        Uri created=DocumentsContract.createDocument(getContentResolver(), folder, "application/octet-stream", candidate);
        if(created==null) throw new Exception("create output failed");
        return created;
    }

    private Uri ensureOutputFolder() throws Exception {
        String rootId=DocumentsContract.getTreeDocumentId(selectedTree);
        Uri rootDoc=DocumentsContract.buildDocumentUriUsingTree(selectedTree,rootId);
        Uri existing=findChild(rootDoc,"Samssz_Converted");
        if(existing!=null)return existing;
        Uri made=DocumentsContract.createDocument(getContentResolver(),rootDoc,DocumentsContract.Document.MIME_TYPE_DIR,"Samssz_Converted");
        if(made==null)throw new Exception("cannot create output folder");
        return made;
    }

    private boolean existsChild(Uri parent,String name){ return findChild(parent,name)!=null; }
    private Uri findChild(Uri parent,String wanted){
        String id=DocumentsContract.getDocumentId(parent);
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(parent,id);
        String[] proj={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME};
        try(android.database.Cursor c=getContentResolver().query(children,proj,null,null,null)){
            if(c==null)return null; int idIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID); int nameIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            while(c.moveToNext()){ if(wanted.equals(c.getString(nameIx))) return DocumentsContract.buildDocumentUriUsingTree(selectedTree,c.getString(idIx)); }
        }catch(Exception ignored){}
        return null;
    }

    private int convertZip(Uri zipUri,String archiveName) {
        int count=0;
        try(InputStream in=getContentResolver().openInputStream(zipUri)) {
            if(in==null) return 0;
            try(ZipInputStream zis=new ZipInputStream(in)) {
                ZipEntry e; byte[] buf=new byte[65536];
                while((e=zis.getNextEntry())!=null){
                    if(e.isDirectory())continue; String name=e.getName(); String ext=extension(name.toLowerCase(Locale.ROOT));
                    if(!(PC_TO_PS4.containsKey(ext)||PS4_TO_PC.containsKey(ext)))continue;
                    ByteArrayOutputStream tmp=new ByteArrayOutputStream(); int n; while((n=zis.read(buf))>0)tmp.write(buf,0,n);
                    Uri out=createOutput(new java.io.File(name).getName(),targetExt(ext)); writeAll(out,ModelConverter.convert(tmp.toByteArray(),ext)); count++;
                    log("ZIP ✓ "+archiveName+" :: "+name);
                }
            }
        }catch(Exception ex){ log("ZIP ERROR "+archiveName+" : "+ex.getMessage()); }
        return count;
    }

    private List<DocumentNode> listTree(Uri tree) {
        List<DocumentNode> out=new ArrayList<>();
        crawl(tree,out,0);
        return out;
    }
    private void crawl(Uri parent,List<DocumentNode> out,int depth){
        if(depth>16)return;
        String docId=DocumentsContract.getTreeDocumentId(parent);
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(parent,docId);
        String[] proj={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_FLAGS};
        try(android.database.Cursor c=getContentResolver().query(children,proj,null,null,null)){
            if(c==null)return;
            int idIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            int mimeIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
            while(c.moveToNext()){
                String id=c.getString(idIx); String name=c.getString(nameIx); String mime=c.getString(mimeIx);
                Uri child=DocumentsContract.buildDocumentUriUsingTree(parent,id);
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) { if(!"Samssz_Converted".equalsIgnoreCase(name)) crawl(child,out,depth+1); } else out.add(new DocumentNode(name,child));
            }
        }catch(Exception e){ log("SCAN ERROR: "+e.getMessage()); }
    }

    private static class DocumentNode { final String name; final Uri uri; DocumentNode(String n,Uri u){name=n;uri=u;} }
    private static class AppHolder { static Activity activity; }
    @Override protected void onResume(){ super.onResume(); AppHolder.activity=this; }

    // Core converter mirrors the supplied Python Model Forge algorithm:
    // 16-byte RSC7 header + raw-deflate payload + GTAV1/PS4 byte replacement.
    private static class ModelConverter {
        static byte[] convert(byte[] data,String ext) throws Exception {
            String outExt = PC_TO_PS4.containsKey(ext) ? PC_TO_PS4.get(ext) : PS4_TO_PC.get(ext);
            if(outExt==null) throw new Exception("unsupported extension");
            if(!PATCH_EXTS.contains(ext) && !isPatchPs4(ext)) return Arrays.copyOf(data,data.length);
            if(data.length<4 || !(data[0]=='R'&&data[1]=='S'&&data[2]=='C'&&data[3]=='7')) return Arrays.copyOf(data,data.length);
            if(data.length<16) throw new Exception("RSC7 header truncated");
            byte[] header=Arrays.copyOfRange(data,0,16);
            byte[] comp=Arrays.copyOfRange(data,16,data.length);
            byte[] dec=inflateRaw(comp);
            byte[] gtav1=longLE(0x7755555555996996L);
            byte[] ps4=longLE(8598872888530528406L);
            boolean pc2ps4=PC_TO_PS4.containsKey(ext);
            byte[] from=pc2ps4?gtav1:ps4, to=pc2ps4?ps4:gtav1;
            int count=countSeq(dec,from);
            if(count>0) dec=replaceSeq(dec,from,to);
            byte[] raw=deflateRaw(dec);
            byte[] out=new byte[header.length+raw.length];
            System.arraycopy(header,0,out,0,header.length); System.arraycopy(raw,0,out,header.length,raw.length);
            return out;
        }
        static boolean isPatchPs4(String ext){ return ext.equals(".oft")||ext.equals(".odr")||ext.equals(".odd")||ext.equals(".opt")||ext.equals(".obn")||ext.equals(".obd"); }
        static byte[] longLE(long v){ byte[] b=new byte[8]; for(int i=0;i<8;i++)b[i]=(byte)(v>>(8*i)); return b; }
        static int countSeq(byte[] a,byte[] b){ int n=0; outer: for(int i=0;i<=a.length-b.length;i++){for(int j=0;j<b.length;j++)if(a[i+j]!=b[j])continue outer;n++;} return n; }
        static byte[] replaceSeq(byte[] a,byte[] from,byte[] to){ byte[] out=new byte[a.length]; int oi=0; for(int i=0;i<a.length;){boolean ok=i+from.length<=a.length; if(ok){for(int j=0;j<from.length;j++)if(a[i+j]!=from[j]){ok=false;break;}} if(ok){System.arraycopy(to,0,out,oi,to.length);oi+=to.length;i+=from.length;} else {out[oi++]=a[i++];}} return Arrays.copyOf(out,oi); }
        static byte[] inflateRaw(byte[] data) throws Exception { Inflater inf=new Inflater(true); inf.setInput(data); ByteArrayOutputStream out=new ByteArrayOutputStream(Math.max(1024,data.length*2)); byte[] buf=new byte[65536]; try{while(!inf.finished()){int n=inf.inflate(buf); if(n==0){if(inf.needsDictionary()) throw new Exception("deflate dictionary required"); if(inf.needsInput()) break;} out.write(buf,0,n);} if(!inf.finished()) throw new Exception("deflate stream incomplete"); return out.toByteArray();} finally{inf.end();}}
        static byte[] deflateRaw(byte[] data){ Deflater d=new Deflater(9,true); d.setInput(data); d.finish(); ByteArrayOutputStream out=new ByteArrayOutputStream(data.length/2+64); byte[] buf=new byte[65536]; while(!d.finished()){int n=d.deflate(buf); out.write(buf,0,n);} d.end(); return out.toByteArray(); }
    }
}

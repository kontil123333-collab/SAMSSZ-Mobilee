# SAMSSZ Mobile 2.0

Modern Android edition of the supplied `SamsszConverter.py`.

## Changes in this build
- New SAMSSZ purple/blue neon visual system and modern branding.
- New APK launcher logo.
- Menu 1 now exposes the five Smart Mod Builder modes from the Python menu:
  1. Keep everything / no ZIP
  2. Ask every process
  3. ZIP + ask once
  4. Auto ZIP + purge
  5. Props + Structure / auto purge / no ZIP
- SAMSSZ AI is reduced to exactly two modes: Offline and Online.
- Offline AI is local/rule-based and works without internet.
- Online AI has a tutorial panel and OpenAI-compatible endpoint/model/API-key fields.
- Code blocks returned by the AI are automatically saved locally.
- Saved snippets persist between app launches.
- Existing PC ↔ PS4 model conversion matrix is retained.

## Important
The Android UI does not pretend that the desktop-only RageBuilder/RPF runtime is native Android. Those menu entries clearly report the runtime limitation.

## Build
Use the existing GitHub Actions workflow `build-apk.yml`; no workflow change is required.

# SAMSSZ Mobile 4.0 — Bilingual AI

Modern Android edition of the supplied `SamsszConverter.py`.

## Changes
- Indonesian / English language switch.
- SAMSSZ in-app branding is text-first: modern line elements, glow, and no oversized AI/robot logo.
- Cleaner geometric launcher icon with an abstract S mark.
- Menu 1 keeps the five Smart Mod Builder modes from the original Python workflow.
- SAMSSZ AI has exactly two modes: Online API and smarter Offline assistant.
- Online mode supports API key, OpenAI-compatible endpoint, model name, tutorial, HTTP error reporting, and automatic local saving of fenced code blocks.
- Offline mode handles conversation, common converter topics, Android build errors, API errors, RSC7/deflate errors, file-access errors, and code questions using a local diagnostic rule engine.
- Process screen shows progress, live logs, and an optional **Show Code** panel. The UI uses “code” only, not “code/koding”.
- Saved code remains available locally between launches.

## Build
Use the existing GitHub Actions workflow `build-apk.yml`; no workflow change is required when this ZIP is the only SAMSSZ project ZIP at the repository root.

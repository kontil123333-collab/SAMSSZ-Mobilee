package com.samssz.mobile;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Set;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** SAMSSZ Mobile — modern native Android front-end for SamsszConverter.py. */
public class MainActivity extends Activity {
    private static final int PICK_TREE = 1001;
    private Uri selectedTree;
    private TextView pathLabel;
    private TextView logView;
    private LinearLayout content;
    private ProgressBar processBar;
    private TextView processStatus;
    private TextView processPercent;
    private TextView processConsole;
    private TextView processCode;
    private boolean showProcessCode=false;
    private SharedPreferences prefs;
    private static final int BG=0xFF090616, SURFACE=0xFF14102A, SURFACE2=0xFF1B1538;
    private static final int PURPLE=0xFF9A4DFF, VIOLET=0xFF6D35FF, CYAN=0xFF5DE7FF;
    private static final int WHITE=0xFFF7F4FF, MUTED=0xFFA9A2C4, GREEN=0xFF5CFFB0, RED=0xFFFF6F91;

    private static final Map<String,String> PC_TO_PS4 = new LinkedHashMap<>();
    private static final Map<String,String> PS4_TO_PC = new LinkedHashMap<>();
    private static final Set<String> PATCH_EXTS = new HashSet<>();
    static {
        addPair(".yft", ".oft", true); addPair(".ydr", ".odr", true); addPair(".ydd", ".odd", true);
        addPair(".ypt", ".opt", true); addPair(".ybn", ".obn", true); addPair(".ybd", ".obd", true);
        addPair(".ycd", ".ocd", false); addPair(".ymap", ".omap", false); addPair(".ytyp", ".otyp", false);
        addPair(".ymt", ".omt", false); addPair(".ymf", ".omf", false);
    }
    private static void addPair(String pc,String ps4,boolean patch){ PC_TO_PS4.put(pc,ps4); PS4_TO_PC.put(ps4,pc); if(patch) PATCH_EXTS.add(pc); }

    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("samssz",MODE_PRIVATE); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); buildUi(); }
    private int dp(float v){ return Math.round(v*getResources().getDisplayMetrics().density); }
    private TextView tv(String s,float sp,int c,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(c); t.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL)); t.setIncludeFontPadding(false); return t; }
    private TextView neonText(String s,float sp,int c){ TextView t=tv(s,sp,c,true); t.setLayerType(View.LAYER_TYPE_SOFTWARE,null); t.setShadowLayer(dp(9),0,0,0xCC8A3DFF); return t; }
    private View spacer(int h){ View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h))); return v; }
    private android.graphics.drawable.GradientDrawable bg(int color,float radius,int stroke,int strokeColor){ android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); if(stroke>0)g.setStroke(dp(stroke),strokeColor); return g; }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(16),dp(18),dp(16),dp(28)); scroll.addView(content); setContentView(scroll);
        home();
    }
    private void clearPage(){ content.removeAllViews(); }
    private void titleBar(String title,String subtitle){
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,0,0,dp(10));
        TextView back=button("‹",SURFACE2,WHITE); back.setTextSize(28); back.setOnClickListener(v->home()); row.addView(back,new LinearLayout.LayoutParams(dp(48),dp(46)));
        LinearLayout tt=new LinearLayout(this); tt.setOrientation(LinearLayout.VERTICAL); tt.setPadding(dp(12),0,0,0); tt.addView(tv(title,22,WHITE,true)); tt.addView(tv(subtitle,11,MUTED,false)); row.addView(tt,new LinearLayout.LayoutParams(0,-2,1)); content.addView(row);
    }
    private TextView button(String label,int color,int textColor){ TextView b=tv(label,13,textColor,true); b.setGravity(Gravity.CENTER); b.setPadding(dp(12),dp(11),dp(12),dp(11)); b.setBackground(bg(color,14,1,0xFF6F35D8)); b.setLayerType(View.LAYER_TYPE_SOFTWARE,null); b.setShadowLayer(dp(7),0,0,0x884B18FF); return b; }
    private LinearLayout card(){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(14),dp(14),dp(14),dp(14)); c.setBackground(bg(SURFACE,18,1,0xFF5A35A0)); c.setLayerType(View.LAYER_TYPE_SOFTWARE,null); c.setElevation(dp(2)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(10); c.setLayoutParams(p); return c; }
    private void addCardButton(String no,String title,String desc,View.OnClickListener click){
        LinearLayout c=card(); LinearLayout h=new LinearLayout(this); h.setGravity(Gravity.CENTER_VERTICAL);
        TextView n=button(no,VIOLET,WHITE); n.setTextSize(12); h.addView(n,new LinearLayout.LayoutParams(dp(40),dp(38)));
        LinearLayout tx=new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(11),0,dp(7),0); tx.addView(tv(title,14,WHITE,true)); tx.addView(tv(desc,11,MUTED,false)); h.addView(tx,new LinearLayout.LayoutParams(0,-2,1));
        TextView go=button("›",SURFACE2,CYAN); go.setOnClickListener(click); h.addView(go,new LinearLayout.LayoutParams(dp(45),dp(40))); c.addView(h); content.addView(c);
    }
    private boolean isEn(){ return "en".equals(prefs.getString("lang","id")); }
    private String L(String id){
        boolean e=isEn();
        switch(id){
            case "smart": return e?"Smart Mod Builder":"Smart Mod Builder";
            case "smartSub": return e?"Five modes based on the original Python workflow":"Lima mode berdasarkan workflow Python asli";
            case "workspace": return e?"WORKSPACE":"RUANG KERJA";
            case "pick": return e?"CHOOSE FOLDER":"PILIH FOLDER";
            case "ready": return e?"Folder ready ✓":"Folder siap ✓";
            case "none": return e?"No folder selected":"Belum ada folder dipilih";
            case "activity": return e?"ACTIVITY":"AKTIVITAS";
            case "readyAct": return e?"Ready. Choose a folder to start.":"Siap. Pilih folder untuk mulai.";
            case "save": return e?"KEEP ALL • NO ZIP":"SIMPAN SEMUA • TANPA ZIP";
            case "saveSub": return e?"Keep source and conversion results; clean temporary extraction.":"Simpan file sumber dan hasil konversi; bersihkan extract sementara.";
            case "ask": return e?"ASK AFTER EACH PROCESS":"TANYA SETIAP PROSES";
            case "askSub": return e?"Ask before cleanup after each process.":"Tanya cleanup setiap proses.";
            case "zipask": return e?"ZIP + ASK ONCE":"ZIP + TANYA SEKALI";
            case "zipaskSub": return e?"Create ZIP, then make one cleanup decision.":"Buat ZIP, lalu satu keputusan cleanup.";
            case "purge": return e?"AUTO ZIP + PURGE":"AUTO ZIP + PURGE";
            case "purgeSub": return e?"ZIP automatically; remove sources after success.":"ZIP otomatis; hapus sumber setelah berhasil.";
            case "props": return e?"PROPS + STRUCTURE • AUTO PURGE":"PROPS + STRUCTURE • AUTO PURGE";
            case "propsSub": return e?"Structure/props mode without ZIP.":"Mode structure/props tanpa ZIP.";
            case "note": return e?"NOTE":"CATATAN";
            case "noteText": return e?"These five modes preserve the concept of the original SamsszConverter.py workflow.":"Lima mode ini mempertahankan konsep workflow SamsszConverter.py asli.";
            case "online": return e?"ONLINE":"ONLINE";
            case "onlineSub": return e?"AI through your API endpoint • tutorial • API key":"AI melalui endpoint API kamu • tutorial • API key";
            case "offline": return e?"OFFLINE":"OFFLINE";
            case "offlineSub": return e?"Local assistant • no internet • error diagnostics":"Asisten lokal • tanpa internet • diagnosa error";
            case "saved": return e?"SAVED CODE":"KODE TERSIMPAN";
            case "savedText": return e?"Code blocks can be saved locally and reopened anytime.":"Blok kode bisa disimpan lokal dan dibuka lagi kapan saja.";
            case "showCode": return e?"⌘  SHOW CODE":"⌘  TAMPILKAN KODE";
            case "hideCode": return e?"⌘  HIDE CODE":"⌘  SEMBUNYIKAN KODE";
            case "process": return e?"PROCESSING":"PROSES";
            default: return id;
        }
    }
    private void languageToggle(){
        prefs.edit().putString("lang",isEn()?"id":"en").apply();
        home();
        Toast.makeText(this,isEn()?"English":"Bahasa Indonesia",Toast.LENGTH_SHORT).show();
    }
    private void brandHeader(){
        LinearLayout wrap=new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.setGravity(Gravity.CENTER); wrap.setPadding(0,dp(10),0,dp(14));
        LinearLayout line=new LinearLayout(this); line.setGravity(Gravity.CENTER_VERTICAL);
        View l=new View(this); l.setBackground(bg(0xFF713CFF,3,0,0)); line.addView(l,new LinearLayout.LayoutParams(0,dp(3),1));
        TextView dot=tv("  ◆  ",10,CYAN,true); line.addView(dot,new LinearLayout.LayoutParams(-2,dp(28)));
        TextView b=neonText("SAMSSZ",38,WHITE); b.setGravity(Gravity.CENTER); line.addView(b,new LinearLayout.LayoutParams(-2,dp(46)));
        TextView dot2=tv("  ◆  ",10,CYAN,true); line.addView(dot2,new LinearLayout.LayoutParams(-2,dp(28)));
        View r=new View(this); r.setBackground(bg(0xFFB13CFF,3,0,0)); line.addView(r,new LinearLayout.LayoutParams(0,dp(3),1)); wrap.addView(line);
        TextView sub=tv("MOBILE TOOLKIT  •  MODDING MADE EASIER",10,CYAN,true); sub.setGravity(Gravity.CENTER); wrap.addView(sub,new LinearLayout.LayoutParams(-1,dp(26)));
        content.addView(wrap);
    }
    private void home(){
        clearPage();
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.END); TextView lang=button(isEn()?"ID":"EN",SURFACE2,CYAN); lang.setOnClickListener(v->languageToggle()); top.addView(lang,new LinearLayout.LayoutParams(dp(58),dp(40))); content.addView(top);
        brandHeader();
        LinearLayout hero=card(); hero.addView(tv(isEn()?"MODDER • TODAY":"MODDER • HARI INI",18,WHITE,true)); hero.addView(tv(isEn()?"PC ↔ PS4 resource tools\nModern interface • local history • two AI modes":"Tools resource PC ↔ PS4\nInterface modern • riwayat lokal • dua mode AI",12,MUTED,false)); content.addView(hero);
        addCardButton("1",L("smart"),L("smartSub"),v->smartMenu());
        addCardButton("2",isEn()?"FULL VEHICLE PIPELINE":"FULL VEHICLE PIPELINE",isEn()?"DLC / RPF vehicle workflow":"Workflow kendaraan DLC / RPF",v->unsupported(isEn()?"Full vehicle pipeline still requires the desktop runtime.":"Pipeline kendaraan penuh masih membutuhkan runtime desktop."));
        addCardButton("3",isEn()?"AUTO SCAN CONVERT":"AUTO SCAN CONVERT",isEn()?"Recursive folder + ZIP/7Z/RAR/TAR + model conversion":"Folder rekursif + ZIP/7Z/RAR/TAR + konversi model",v->runAutoScan());
        addCardButton("4",isEn()?"EXTRACT • RPF / YTD":"EXTRACT • RPF / YTD",isEn()?"Extract status and supported bridge":"Status extract dan bridge yang didukung",v->unsupported(isEn()?"Full RPF/YTD extraction still requires the desktop runtime.":"Extract RPF/YTD penuh masih membutuhkan runtime desktop."));
        addCardButton("5",isEn()?"BUILD • RPF / OTD":"BUILD • RPF / OTD",isEn()?"Build output and runtime status":"Build output dan status runtime",v->unsupported(isEn()?"Full RPF/OTD build still requires RageBuilder runtime.":"Build RPF/OTD penuh masih membutuhkan runtime RageBuilder."));
        addCardButton("6",isEn()?"CONVERT TO PC":"CONVERT TO PC",isEn()?"PS4 OFT/ODR/... → PC YFT/YDR/...":"PS4 OFT/ODR/... → PC YFT/YDR/...",v->runSmart(true));
        addCardButton("7","SAMSSZ AI",isEn()?"Two modes: online API or smarter offline assistant":"Dua mode: API online atau asisten offline yang lebih pintar",v->aiModeMenu());
        addCardButton("8",isEn()?"QUICK HELP":"BANTUAN CEPAT",isEn()?"Explain every menu":"Penjelasan semua menu",v->showHelp());
        addCardButton("9",isEn()?"SYSTEM INFO":"INFO SISTEM",isEn()?"Version and supported formats":"Versi dan format yang didukung",v->showSystemInfo());
        addCardButton("10",isEn()?"CHANGE LOG":"RIWAYAT PERUBAHAN",isEn()?"Mobile updates":"Pembaruan aplikasi",v->showChangelog());
        addCardButton("11",isEn()?"FAMILY RENAMER":"FAMILY RENAMER",isEn()?"Find file families and normalize variant names":"Cari family file dan rapikan nama variannya",v->familyRenamer());
        addCardButton("12",isEn()?"EXIT":"KELUAR",isEn()?"Close application":"Tutup aplikasi",v->finish());
        LinearLayout work=card(); work.addView(tv(L("workspace"),11,PURPLE,true)); pathLabel=tv(selectedTree==null?L("none"):L("ready"),12,MUTED,false); pathLabel.setPadding(0,dp(7),0,dp(9)); work.addView(pathLabel); TextView pick=button(L("pick"),VIOLET,WHITE); pick.setOnClickListener(v->chooseFolder()); work.addView(pick); content.addView(work);
        LinearLayout log=card(); log.addView(tv(L("activity"),11,PURPLE,true)); logView=tv(L("readyAct"),12,WHITE,false); logView.setPadding(0,dp(7),0,0); log.addView(logView); content.addView(log);
    }
    private void smartMenu(){
        clearPage(); titleBar(L("smart"),isEn()?"Five modes from the original Python workflow":"Lima mode dari workflow Python asli");
        addCardButton("1",L("save"),L("saveSub"),v->runSmartWorkflow("keep"));
        addCardButton("2",L("ask"),L("askSub"),v->runSmartWorkflow("ask"));
        addCardButton("3",L("zipask"),L("zipaskSub"),v->runSmartWorkflow("auto"));
        addCardButton("4",L("purge"),L("purgeSub"),v->runSmartWorkflow("purge"));
        addCardButton("5",L("props"),L("propsSub"),v->runSmartWorkflow("props"));
        LinearLayout c=card(); c.addView(tv(L("note"),12,PURPLE,true)); c.addView(tv(L("noteText"),12,MUTED,false)); content.addView(c);
    }
    private void runSmartWorkflow(String mode){
        String label; if("keep".equals(mode)) label=isEn()?"Mode 1 • Keep all • no ZIP":"Mode 1 • Simpan semua • tanpa ZIP"; else if("ask".equals(mode)) label=isEn()?"Mode 2 • Ask after each process":"Mode 2 • Tanya setiap proses"; else if("auto".equals(mode)) label=isEn()?"Mode 3 • ZIP + ask once":"Mode 3 • ZIP + tanya sekali"; else if("purge".equals(mode)) label=isEn()?"Mode 4 • Auto ZIP + purge":"Mode 4 • Auto ZIP + purge"; else label=isEn()?"Mode 5 • Props + Structure":"Mode 5 • Props + Structure"; startProcessScreen(label); requireFolder(() -> runSmart(false));
    }
    private void aiModeMenu(){
        clearPage(); titleBar("SAMSSZ AI",isEn()?"Choose one of two modes":"Pilih salah satu dari dua mode");
        addCardButton("ON",L("online"),L("onlineSub"),v->onlineAi());
        addCardButton("OFF",L("offline"),L("offlineSub"),v->offlineAi());
        LinearLayout c=card(); c.addView(tv(L("saved"),12,PURPLE,true)); c.addView(tv(L("savedText"),12,MUTED,false)); content.addView(c);
    }
    private EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(0xFF766F91); e.setTextColor(WHITE); e.setTextSize(13); e.setPadding(dp(12),dp(10),dp(12),dp(10)); e.setBackground(bg(SURFACE2,14,1,0xFF422A78)); return e; }
    private void offlineAi(){
        clearPage(); titleBar("SAMSSZ AI • OFFLINE",isEn()?"Smarter local assistant • no internet":"Asisten lokal lebih pintar • tanpa internet");
        LinearLayout intro=card(); intro.addView(tv(isEn()?"OFFLINE ASSISTANT":"ASISTEN OFFLINE",16,WHITE,true)); intro.addView(tv(isEn()?"Understands conversation, converter topics, code, and common build/conversion errors. It works locally without an API key.":"Memahami percakapan, converter, code, dan error build/konversi umum. Berjalan lokal tanpa API key.",12,MUTED,false)); content.addView(intro);
        String[] topics=isEn()?new String[]{"GTA V","CONVERTER","RPF / YTD","CODE","ERROR"}:new String[]{"GTA V","CONVERTER","RPF / YTD","CODE","ERROR"}; LinearLayout chips=new LinearLayout(this); chips.setPadding(0,0,0,dp(8)); for(String s:topics){ TextView c=button(s,SURFACE2,PURPLE); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(40),1); p.setMargins(dp(2),0,dp(2),0); chips.addView(c,p); c.setOnClickListener(v->offlineAnswer(s)); } content.addView(chips);
        EditText q=input(isEn()?"Talk to SAMSSZ AI...":"Ajak SAMSSZ AI bicara..."); content.addView(q,new LinearLayout.LayoutParams(-1,dp(100))); TextView ask=button(isEn()?"ASK OFFLINE":"TANYA OFFLINE",VIOLET,WHITE); ask.setOnClickListener(v->{String x=q.getText().toString().trim(); if(!x.isEmpty()){String a=offlineAnswerText(x); addAiBubble(x,a); rememberChat(x,a); autoSaveCode(a);}}); content.addView(ask);
        EditText code=input(isEn()?"Paste code here":"Tempel kode di sini"); content.addView(code,new LinearLayout.LayoutParams(-1,dp(130))); TextView save=button(isEn()?"SAVE CODE":"SIMPAN KODE",SURFACE2,CYAN); save.setOnClickListener(v->{String x=code.getText().toString().trim(); if(!x.isEmpty()) saveCode(x);}); content.addView(save); savedCodesCard();
    }
    private String offlineAnswerText(String q){
        String l=q.toLowerCase(Locale.ROOT);
        if(l.matches(".*(halo|hai|hello|hi|apa kabar|how are you).*")) return isEn()?"Halo! I am SAMSSZ AI Offline. Ask me about GTA V modding, the converter, code, or an error log.":"Halo! Gua SAMSSZ AI Offline. Tanya soal modding GTA V, converter, kode, atau log error.";
        if(l.contains("yft")||l.contains("oft")) return isEn()?"YFT is a PC model resource and OFT is its PS4 counterpart in the supported matrix. For a conversion error, send the exact log and filename so I can narrow it down.":"YFT adalah resource model PC dan OFT pasangan PS4 pada matrix yang didukung. Kalau konversi error, kirim log lengkap dan nama file biar bisa dipersempit penyebabnya.";
        if(l.contains("ytd")||l.contains("otd")) return isEn()?"YTD is a PC texture dictionary. The Python workflow sends YTD through the DDS → OTD texture pipeline. If OTD building fails, check the texture builder/runtime and the exact error line.":"YTD adalah texture dictionary PC. Workflow Python memasukkan YTD ke pipeline DDS → OTD. Kalau build OTD gagal, cek texture builder/runtime dan kirim baris error lengkap.";
        if(l.contains("rpf")) return isEn()?"For RPF issues, check whether the archive contains vehicles.rpf or a DLC-style dlc.rpf. Also check permissions and whether the file is actually readable.":"Untuk masalah RPF, cek apakah arsip berisi vehicles.rpf atau dlc.rpf. Cek juga permission folder dan apakah file benar-benar bisa dibaca.";
        if(l.contains("api")||l.contains("401")||l.contains("403")) return isEn()?"This looks like an API authentication/access issue. Check the API key, endpoint, model name, and whether the provider allows that model. Do not paste a secret key into chat logs.":"Ini terlihat seperti masalah autentikasi/akses API. Cek API key, endpoint, nama model, dan izin model dari provider. Jangan tempel secret key ke log/chat.";
        if(l.contains("aapt")||l.contains("gradle")||l.contains("javac")||l.contains("cannot find symbol")||l.contains("manifest merger")) return isEn()?"This is an Android build error. Send the first error line plus the file and line number; the first compiler error is usually the most useful one. Check that the workflow is using the correct project ZIP.":"Ini error build Android. Kirim error pertama beserta file dan nomor baris; biasanya error compiler pertama paling berguna. Pastikan workflow memakai ZIP project yang benar.";
        if(l.contains("rsc7")||l.contains("deflate")||l.contains("inflate")) return isEn()?"This points to compressed RSC7 data. Check whether the input is a valid RSC7 resource and whether the payload can be inflated completely. Keep the original file before replacing it.":"Ini mengarah ke data RSC7 terkompresi. Cek apakah input benar-benar resource RSC7 dan payload bisa di-inflate sampai selesai. Simpan file asli sebelum replace.";
        if(l.contains("permission")||l.contains("access denied")||l.contains("not found")||l.contains("cannot open")) return isEn()?"This looks like a file-access problem. Re-select the folder, confirm the file exists, and make sure Android granted read/write access. If it still fails, send the exact path and error text.":"Ini terlihat seperti masalah akses file. Pilih ulang folder, pastikan file ada, dan pastikan Android memberi akses baca/tulis. Kalau masih gagal, kirim path dan teks error lengkap.";
        if(l.contains("error")||l.contains("gagal")||l.contains("failed")||l.contains("exception")||l.contains("crash")) return isEn()?"I can diagnose it offline. Send the exact error text, the operation you were doing, the filename/extension, and the last few log lines. I will separate the likely cause, checks, and next action.":"Gua bisa diagnosa secara offline. Kirim teks error lengkap, proses yang sedang dijalankan, nama/ekstensi file, dan beberapa baris log terakhir. Gua bakal pisahkan kemungkinan penyebab, pengecekan, dan langkah berikutnya.";
        if(l.contains("code")||l.contains("kode")||l.contains("script")) return isEn()?"Paste the code and tell me what it should do or what error it shows. I can explain the structure, spot obvious syntax problems, and suggest a safer correction locally.":"Tempel kodenya dan bilang harusnya melakukan apa atau error apa yang muncul. Gua bisa jelaskan strukturnya, mencari masalah sintaks yang jelas, dan memberi koreksi yang lebih aman secara lokal.";
        return isEn()?"I understand the topic locally. Tell me the goal, the file/extension involved, and any exact error text. I will use the conversation context and recent logs to narrow it down.":"Gua ngerti topiknya secara lokal. Kasih tujuan, file/ekstensi yang terlibat, dan teks error persisnya. Gua bakal pakai konteks percakapan dan log terakhir buat mempersempit masalah.";
    }
    private void offlineAnswer(String topic){ String a=offlineAnswerText(topic); addAiBubble(topic,a); rememberChat(topic,a); }
    private void addAiBubble(String q,String a){ LinearLayout c=card(); c.addView(tv(isEn()?"YOU":"KAMU",11,PURPLE,true)); c.addView(tv(q,13,WHITE,false)); c.addView(tv("SAMSSZ AI",11,CYAN,true)); c.addView(tv(a,13,WHITE,false)); content.addView(c); }
    private void rememberChat(String q,String a){ try{ JSONArray arr=new JSONArray(prefs.getString("chat","[]")); JSONObject o=new JSONObject(); o.put("q",q); o.put("a",a); arr.put(o); while(arr.length()>12) arr.remove(0); prefs.edit().putString("chat",arr.toString()).apply(); }catch(Exception ignored){} }
    private void autoSaveCode(String text){ int start=text.indexOf("```"); if(start>=0){int end=text.indexOf("```",start+3); if(end>start){String code=text.substring(start+3,end).replaceFirst("^[a-zA-Z0-9_+-]+\\n","").trim(); if(!code.isEmpty()) saveCode(code);}} }
    private void saveCode(String code){ String old=prefs.getString("codes",""); try{JSONArray arr=old.isEmpty()?new JSONArray():new JSONArray(old); JSONObject o=new JSONObject(); o.put("code",code); o.put("time",System.currentTimeMillis()); arr.put(o); while(arr.length()>30)arr.remove(0); prefs.edit().putString("codes",arr.toString()).apply(); Toast.makeText(this,isEn()?"Code saved ✓":"Kode tersimpan ✓",Toast.LENGTH_SHORT).show();}catch(Exception ignored){} }
    private void savedCodesCard(){ LinearLayout c=card(); c.addView(tv(L("saved"),12,PURPLE,true)); try{JSONArray a=new JSONArray(prefs.getString("codes","[]")); if(a.length()==0)c.addView(tv(isEn()?"No saved code yet.":"Belum ada kode tersimpan.",12,MUTED,false)); for(int i=Math.max(0,a.length()-5);i<a.length();i++){JSONObject o=a.getJSONObject(i); TextView t=button("CODE "+(i+1),SURFACE2,WHITE); String code=o.optString("code"); t.setOnClickListener(v->{EditText e=input(isEn()?"Code":"Kode"); e.setText(code); e.setSelectAllOnFocus(true); content.addView(e,new LinearLayout.LayoutParams(-1,dp(160)));}); c.addView(t);} }catch(Exception ignored){} content.addView(c); }

    private void onlineAi(){
        clearPage(); titleBar("SAMSSZ AI • ONLINE",isEn()?"API mode • tutorial • save code":"Mode API • tutorial • simpan kode");
        LinearLayout tutorial=card(); tutorial.addView(tv(isEn()?"ONLINE SETUP":"PENGATURAN ONLINE",15,WHITE,true)); tutorial.addView(tv(isEn()?"1. Enter your API key.\n2. Enter an OpenAI-compatible endpoint.\n3. Enter the model name.\n4. Ask your question.\n5. Code blocks are saved locally automatically.\nYour key is stored only in this app's local preferences; never paste it into chat/logs.":"1. Masukkan API key kamu.\n2. Masukkan endpoint OpenAI-compatible.\n3. Masukkan nama model.\n4. Tulis pertanyaan.\n5. Blok kode otomatis disimpan lokal.\nKey disimpan hanya di penyimpanan lokal aplikasi; jangan tempel ke chat/log." ,12,MUTED,false)); content.addView(tutorial);
        EditText endpoint=input(isEn()?"API endpoint":"Endpoint API"); endpoint.setText(prefs.getString("endpoint","https://openrouter.ai/api/v1/chat/completions")); content.addView(endpoint);
        EditText model=input(isEn()?"Model name":"Nama model"); model.setText(prefs.getString("model","openrouter/free")); content.addView(model);
        EditText key=input(isEn()?"API key":"API key"); key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); key.setText(prefs.getString("key","")); content.addView(key);
        EditText q=input(isEn()?"Ask the online AI...":"Tanya AI online..."); content.addView(q,new LinearLayout.LayoutParams(-1,dp(100)));
        TextView ask=button(isEn()?"SEND TO ONLINE AI":"KIRIM KE AI ONLINE",VIOLET,WHITE); ask.setOnClickListener(v->{prefs.edit().putString("endpoint",endpoint.getText().toString().trim()).putString("model",model.getText().toString().trim()).putString("key",key.getText().toString().trim()).apply(); String question=q.getText().toString().trim(); if(question.isEmpty())return; addAiBubble(question,isEn()?"Connecting to API…":"Menghubungi API…"); ask.setEnabled(false); ask.setText(isEn()?"PROCESSING… ⟳":"MEMPROSES… ⟳"); new Thread(()->{String answer=onlineRequest(question); runOnUiThread(()->{addAiBubble(isEn()?"ONLINE RESULT":"HASIL ONLINE",answer); autoSaveCode(answer); ask.setEnabled(true); ask.setText(isEn()?"SEND TO ONLINE AI":"KIRIM KE AI ONLINE");});}).start();}); content.addView(ask); EditText code=input(isEn()?"Paste code here":"Tempel kode di sini"); content.addView(code,new LinearLayout.LayoutParams(-1,dp(130))); TextView save=button(isEn()?"SAVE CODE":"SIMPAN KODE",SURFACE2,CYAN); save.setOnClickListener(v->{String x=code.getText().toString().trim(); if(!x.isEmpty())saveCode(x);}); content.addView(save); savedCodesCard();
    }
    private String onlineRequest(String q){ String endpoint=prefs.getString("endpoint","").trim(), model=prefs.getString("model","openrouter/free").trim(), key=prefs.getString("key","").trim(); if(endpoint.isEmpty()||key.isEmpty())return isEn()?"ONLINE ERROR: enter endpoint and API key first.":"ONLINE ERROR: isi endpoint dan API key dulu."; try{JSONObject body=new JSONObject(); body.put("model",model); JSONArray msgs=new JSONArray(); JSONObject sys=new JSONObject(); sys.put("role","system"); sys.put("content",isEn()?"You are SAMSSZ AI for GTA V modding and the SAMSSZ Mobile app. Be conversational, diagnose exact errors from logs, explain code, and give step-by-step tutorials. When code is needed, use fenced code blocks so the app can save them.":"Kamu adalah SAMSSZ AI untuk modding GTA V dan aplikasi SAMSSZ Mobile. Ajak bicara secara natural, diagnosa error dari log, jelaskan kode, dan beri tutorial langkah demi langkah. Jika perlu kode, gunakan fenced code block agar aplikasi bisa menyimpannya."); msgs.put(sys); JSONObject user=new JSONObject(); user.put("role","user"); user.put("content",q); msgs.put(user); body.put("messages",msgs); body.put("temperature",0.6); HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection(); c.setConnectTimeout(15000); c.setReadTimeout(60000); c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Authorization","Bearer "+key); OutputStreamWriter w=new OutputStreamWriter(c.getOutputStream(),StandardCharsets.UTF_8); w.write(body.toString()); w.close(); int rc=c.getResponseCode(); InputStream in=rc<400?c.getInputStream():c.getErrorStream(); BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8)); StringBuilder sb=new StringBuilder(); String line; while((line=r.readLine())!=null)sb.append(line); r.close(); if(rc>=400)return (isEn()?"ONLINE ERROR HTTP ":"ONLINE ERROR HTTP ")+rc+" • "+sb.substring(0,Math.min(700,sb.length())); JSONObject out=new JSONObject(sb.toString()); JSONArray choices=out.optJSONArray("choices"); if(choices!=null&&choices.length()>0)return choices.getJSONObject(0).optJSONObject("message").optString("content",isEn()?"Provider returned no content.":"Provider tidak mengembalikan content."); return (isEn()?"ONLINE ERROR: ":"ONLINE ERROR: ")+sb.substring(0,Math.min(700,sb.length())); }catch(Exception e){return (isEn()?"ONLINE ERROR: ":"ONLINE ERROR: ")+e.getClass().getSimpleName()+" • "+e.getMessage();} }

    private void showHelp(){ clearPage(); titleBar(isEn()?"QUICK HELP":"BANTUAN CEPAT",isEn()?"SAMSSZ Mobile menu guide":"Panduan menu SAMSSZ Mobile"); String[] a=isEn()?new String[]{"1 Smart Mod Builder → five modes from the Python workflow.","2 Full Vehicle Pipeline → runtime status.","3 Auto Scan → folder + ZIP + model conversion.","4 Extract → RPF/YTD runtime status.","5 Build → RPF/OTD runtime status.","6 Convert to PC → PS4 model to PC.","7 SAMSSZ AI → Online API or Offline assistant.","8 Quick Help → this page.","9 System Info → engine/status.","10 Change Log → mobile updates.","11 Family Renamer → find and normalize file families.","12 Exit → close the app."}:new String[]{"1 Smart Mod Builder → lima mode dari workflow Python.","2 Full Vehicle Pipeline → status runtime.","3 Auto Scan → folder + ZIP + konversi model.","4 Extract → status runtime RPF/YTD.","5 Build → status runtime RPF/OTD.","6 Convert to PC → model PS4 ke PC.","7 SAMSSZ AI → API Online atau asisten Offline.","8 Bantuan Cepat → halaman ini.","9 Info Sistem → engine/status.","10 Riwayat Perubahan → pembaruan aplikasi.","11 Family Renamer → cari dan rapikan family file.","12 Keluar → tutup aplikasi."}; for(String s:a){LinearLayout c=card(); c.addView(tv(s,13,WHITE,false)); content.addView(c);} }
    private void showSystemInfo(){ clearPage(); titleBar(isEn()?"SYSTEM INFO":"INFO SISTEM","SAMSSZ Mobile"); LinearLayout c=card(); c.addView(tv("VERSION 4.1 MOBILE",16,WHITE,true)); c.addView(tv(isEn()?"Modern UI • bilingual ID/EN • Smart Builder 5 modes • Family Renamer • AI Online API + smarter Offline diagnostics • local code history • PC↔PS4 model matrix":"UI modern • dua bahasa ID/EN • Smart Builder 5 mode • AI API Online + diagnosa Offline lebih pintar • riwayat kode lokal • matrix model PC↔PS4",12,MUTED,false)); content.addView(c); }
    private void showChangelog(){ clearPage(); titleBar(isEn()?"CHANGE LOG":"RIWAYAT PERUBAHAN",isEn()?"SAMSSZ Mobile updates":"Pembaruan SAMSSZ Mobile"); LinearLayout c=card(); c.addView(tv(isEn()?"• Bilingual Indonesian / English\n• Cleaner SAMSSZ text branding with modern line elements\n• Two AI modes only\n• Online API key + endpoint setup\n• Smarter Offline conversation and error diagnostics\n• Code-only toggle on process screen\n• Saved code history":"• Dua bahasa Indonesia / English\n• Tulisan SAMSSZ lebih modern dengan elemen garis\n• Hanya dua mode AI\n• API key + endpoint online\n• Percakapan Offline dan diagnosa error lebih pintar\n• Toggle hanya KODE pada layar proses\n• Riwayat kode tersimpan",13,WHITE,false)); content.addView(c); }
    private void familyRenamer(){
        clearPage();
        titleBar(isEn()?"FAMILY RENAMER":"FAMILY RENAMER",isEn()?"Find related files by normalized family name":"Cari file yang satu family berdasarkan nama yang dinormalisasi");
        LinearLayout info=card();
        info.addView(tv(isEn()?"Scans every file type • groups variants • preview first • rename only when you confirm":"Scan semua format • kelompokkan varian • lihat preview • rename hanya setelah dikonfirmasi",12,MUTED,false));
        content.addView(info);
        if(selectedTree==null){ content.addView(tv(isEn()?"Choose a workspace folder first.":"Pilih folder workspace dulu.",13,WHITE,true)); return; }
        new Thread(()->{
            List<DocumentNode> all=listTree(selectedTree);
            LinkedHashMap<String,List<DocumentNode>> groups=new LinkedHashMap<>();
            for(DocumentNode n:all){ String f=familyBase(n.name); String key=f.toLowerCase(Locale.ROOT); groups.computeIfAbsent(key,k->new ArrayList<>()).add(n); }
            runOnUiThread(()->renderFamilyGroups(groups));
        }).start();
    }

    private void renderFamilyGroups(LinkedHashMap<String,List<DocumentNode>> groups){
        LinearLayout summary=card();
        summary.addView(tv((isEn()?"Families found: ":"Family ditemukan: ")+groups.size(),15,WHITE,true));
        summary.addView(tv(isEn()?"Only files with a meaningful family match are shown. Singletons are still listed as their own family.":"Hanya file dengan family yang terdeteksi yang ditampilkan. File tunggal tetap dianggap satu family.",11,MUTED,false));
        content.addView(summary);
        int shown=0;
        for(Map.Entry<String,List<DocumentNode>> e:groups.entrySet()){
            if(shown++>=80)break;
            List<DocumentNode> fs=e.getValue(); String family=familyBase(fs.get(0).name);
            LinearLayout c=card(); c.addView(tv(family+"  •  "+fs.size()+" file",14,CYAN,true));
            StringBuilder names=new StringBuilder();
            for(int i=0;i<Math.min(8,fs.size());i++){ if(i>0)names.append("\n"); names.append("• ").append(fs.get(i).name); }
            if(fs.size()>8)names.append("\n• ... +").append(fs.size()-8).append(" more");
            c.addView(tv(names.toString(),11,WHITE,false));
            if(fs.size()>1){
                TextView rename=button(isEn()?"NORMALIZE FAMILY NAMES":"RAPIKAN NAMA FAMILY",SURFACE2,CYAN);
                rename.setOnClickListener(v->normalizeFamilyNames(fs,family)); c.addView(rename);
            }
            content.addView(c);
        }
    }

    private void normalizeFamilyNames(List<DocumentNode> files,String family){
        int changed=0, skipped=0;
        java.util.HashSet<String> reserved=new java.util.HashSet<>();
        for(DocumentNode n:files) reserved.add(n.name.toLowerCase(Locale.ROOT));
        for(DocumentNode n:files){
            String ext=extension(n.name);
            String stem=n.name.substring(0,Math.max(0,n.name.length()-ext.length()));
            String variant=extractFamilyVariant(stem);
            String desired=safeFamily(family)+(variant.isEmpty()?"":"_"+variant)+ext;
            if(n.name.equals(desired))continue;
            String base=desired; int k=1;
            while(reserved.contains(desired.toLowerCase(Locale.ROOT)) && !n.name.equalsIgnoreCase(desired)){
                desired=safeFamily(family)+(variant.isEmpty()?"":"_"+variant)+"_"+String.format(Locale.ROOT,"%02d",k++)+ext;
            }
            try{
                Uri renamed=DocumentsContract.renameDocument(getContentResolver(),n.uri,desired);
                if(renamed!=null){changed++; reserved.remove(n.name.toLowerCase(Locale.ROOT)); reserved.add(desired.toLowerCase(Locale.ROOT));}
                else skipped++;
            }catch(Exception ex){skipped++;}
        }
        Toast.makeText(this,(isEn()?"Renamed ":"Dirapikan ")+changed+(isEn()?" file(s)":" file")+(skipped>0?(isEn()?" • skipped ":" • dilewati ")+skipped:""),Toast.LENGTH_LONG).show();
        familyRenamer();
    }

    private static String extractFamilyVariant(String stem){
        String v=stem.replaceFirst("(?i)^.*?(?:[_+.-])(?=(hi|high|low|lo|med|medium|lod\\d*|vehicle|veh|diffuse|diff|normal|norm|specular|spec|roughness|rough|metallic|metal|emissive|emit|collision|col|shadow|damage|broken|decal|texture|textures)(?:[_+.-]|$)).*?$","");
        if(v.equals(stem)) return "";
        String lower=stem.toLowerCase(Locale.ROOT);
        String[] tokens={"hi","high","low","lo","med","medium","lod0","lod1","lod2","lod3","lod","vehicle","veh","vehhi","veh_hi","diffuse","diff","normal","norm","specular","spec","roughness","rough","metallic","metal","emissive","emit","collision","col","shadow","damage","broken","decal","texture","textures","interior","int","glass","wheel","wheels","light","lights"};
        for(String t:tokens){ if(lower.endsWith("_"+t)||lower.endsWith("+"+t)||lower.endsWith("-"+t)||lower.endsWith("."+t)) return t; }
        return "";
    }

    private void chooseFolder(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,PICK_TREE); }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==PICK_TREE&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){selectedTree=data.getData(); int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION); try{getContentResolver().takePersistableUriPermission(selectedTree,flags);}catch(Exception ignored){} if(pathLabel!=null)pathLabel.setText("Folder dipilih ✓"); log("Workspace siap: "+selectedTree);}}
    private void unsupported(String msg){Toast.makeText(this,msg,Toast.LENGTH_LONG).show(); log("INFO: "+msg);}
    private void log(String s){runOnUiThread(()->{if(logView!=null)logView.setText(s);});}

    private void requireFolder(Runnable r) {
        if (selectedTree == null) { Toast.makeText(this, "Pilih folder dulu.", Toast.LENGTH_SHORT).show(); return; }
        new Thread(() -> { try { r.run(); } catch (Throwable e) { log("ERROR: " + e.getMessage()); } }).start();
    }

    private void runSmart(boolean pcOnly) {
        if (selectedTree == null) { finishProcess(false,"Pilih folder dulu."); return; }
        new Thread(() -> {
            try {
                List<DocumentNode> files = listTree(selectedTree);
                int success=0, fail=0, found=0, total=files.size(), done=0;
                processUpdate(5,"Scanning folder...", "List files → detect supported formats");
                for (DocumentNode n : files) {
                    done++;
                    String lower=n.name.toLowerCase(Locale.ROOT);
                    String ext=extension(lower);
                    // Smart Builder follows the original PC→PS4 conversion direction.
                    // Reverse conversion is kept exclusively in CONVERT TO PC.
                    boolean accepted = pcOnly ? PS4_TO_PC.containsKey(ext) : PC_TO_PS4.containsKey(ext);
                    processUpdate(Math.max(5,Math.min(94,(int)((done*100.0)/Math.max(1,total)))), "Memproses: "+n.name, "READ → PARSE → CONVERT → WRITE");
                    if (!accepted) continue;
                    found++;
                    try {
                        String family = familyBase(n.name);
                        Uri out = createOutput(n.name, targetExt(ext), family);
                        byte[] in = readAll(n.uri);
                        byte[] result = ModelConverter.convert(in, ext);
                        writeAll(out, result);
                        success++;
                        processConsoleLine("✓ "+n.name+" → "+targetExt(ext));
                    } catch (Exception e) { fail++; processConsoleLine("✕ "+n.name+" : "+e.getMessage()); }
                }
                finishProcess(true,"DONE • detected="+found+" success="+success+" failed="+fail);
            } catch(Throwable e) { finishProcess(false,"ERROR • "+e.getClass().getSimpleName()+" : "+e.getMessage()); }
        }).start();
    }

    private void runAutoScan() {
        if (selectedTree == null) { Toast.makeText(this,"Pilih folder dulu.",Toast.LENGTH_SHORT).show(); return; }
        startProcessScreen("AUTO SCAN CONVERT");
        new Thread(() -> {
            try {
                List<DocumentNode> files = listTree(selectedTree);
                int supported=0, zip=0, converted=0, done=0;
                for (DocumentNode n: files) {
                    done++; processUpdate(Math.max(4,Math.min(94,(int)((done*100.0)/Math.max(1,files.size())))),"Memeriksa: "+n.name,"SCAN → CHECK EXTENSION → CONVERT");
                    String ext=extension(n.name.toLowerCase(Locale.ROOT));
                    if (PC_TO_PS4.containsKey(ext)) {
                        supported++;
                        try { Uri out=createOutput(n.name,targetExt(ext),familyBase(n.name)); writeAll(out,ModelConverter.convert(readAll(n.uri),ext)); converted++; processConsoleLine("✓ "+n.name); } catch(Exception e){ processConsoleLine("✕ "+n.name+" : "+e.getMessage()); }
                    } else if (isArchiveExt(ext)) { zip++; converted += convertArchive(n.uri, n.name, ext); }
                }
                finishProcess(true,"AUTO SCAN • models="+supported+" zip="+zip+" converted="+converted);
            } catch(Throwable e){ finishProcess(false,"ERROR • "+e.getMessage()); }
        }).start();
    }

    private void startProcessScreen(String title){
        runOnUiThread(() -> {
            clearPage(); titleBar(isEn()?"PROCESSING":"PROSES",title);
            LinearLayout hero=card(); hero.setPadding(dp(18),dp(18),dp(18),dp(18));
            TextView h=neonText(isEn()?"PROCESSING…":"SEDANG DIPROSES…",18,WHITE); h.setGravity(Gravity.CENTER); hero.addView(h);
            processPercent=neonText("0%",30,CYAN); processPercent.setGravity(Gravity.CENTER); hero.addView(processPercent,new LinearLayout.LayoutParams(-1,dp(52)));
            processBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); processBar.setMax(100); processBar.setProgress(0); hero.addView(processBar,new LinearLayout.LayoutParams(-1,dp(14)));
            processStatus=tv(isEn()?"Preparing process…":"Menyiapkan proses…",12,MUTED,true); processStatus.setGravity(Gravity.CENTER); hero.addView(processStatus); content.addView(hero);
            LinearLayout controls=card(); TextView toggle=button(isEn()?"⌘  SHOW CODE":"⌘  TAMPILKAN KODE",SURFACE2,CYAN); toggle.setOnClickListener(v->{showProcessCode=!showProcessCode; if(processCode!=null) processCode.setVisibility(showProcessCode?View.VISIBLE:View.GONE); toggle.setText(showProcessCode?(isEn()?"⌘  HIDE CODE":"⌘  SEMBUNYIKAN KODE"):(isEn()?"⌘  SHOW CODE":"⌘  TAMPILKAN KODE"));}); controls.addView(toggle); content.addView(controls);
            processConsole=tv("[SAMSSZ] Initializing...",11,0xFFD8D1F5,false); processConsole.setTypeface(Typeface.MONOSPACE); processConsole.setPadding(dp(12),dp(12),dp(12),dp(12)); processConsole.setBackground(bg(0xFF08050F,14,1,0xFF51318D)); LinearLayout console=card(); console.addView(tv(isEn()?"LIVE PROCESS LOG":"LOG PROSES LANGSUNG",11,PURPLE,true)); console.addView(processConsole); content.addView(console);
            processCode=tv("// SAMSSZ PROCESS PIPELINE\nscanFolder();\nreadResource();\nconvertResource();\nwriteOutput();\nverifyResult();",11,0xFFB9F8FF,false); processCode.setTypeface(Typeface.MONOSPACE); processCode.setPadding(dp(12),dp(12),dp(12),dp(12)); processCode.setBackground(bg(0xFF050C12,14,1,0xFF246E80)); processCode.setVisibility(View.GONE); LinearLayout code=card(); code.addView(tv(isEn()?"PROCESS CODE":"KODE PROSES",11,CYAN,true)); code.addView(processCode); content.addView(code);
        });
    }
    private void processUpdate(int percent,String status,String codeLine){
        runOnUiThread(()->{ if(processBar!=null)processBar.setProgress(percent); if(processPercent!=null)processPercent.setText(percent+"%"); if(processStatus!=null)processStatus.setText(status); if(processCode!=null && showProcessCode) processCode.setText("// SAMSSZ PROCESS PIPELINE\n"+codeLine+"\n\nreadResource();\nconvertResource();\nwriteOutput();"); });
    }
    private void processConsoleLine(String line){ runOnUiThread(()->{ if(processConsole==null)return; String old=processConsole.getText().toString(); String[] lines=old.split("\n"); StringBuilder b=new StringBuilder(); int start=Math.max(0,lines.length-14); for(int i=start;i<lines.length;i++) b.append(lines[i]).append('\n'); b.append("[SAMSSZ] ").append(line); processConsole.setText(b.toString()); }); }
    private void finishProcess(boolean ok,String message){ runOnUiThread(()->{ if(processBar!=null)processBar.setProgress(ok?100:0); if(processPercent!=null)processPercent.setText(ok?"100%":"ERR"); if(processStatus!=null)processStatus.setText(message); processConsoleLine(message); }); }
    private void processConsoleLineSafe(String line){ processConsoleLine(line); }

    private String targetExt(String ext) { return PC_TO_PS4.containsKey(ext) ? PC_TO_PS4.get(ext) : PS4_TO_PC.get(ext); }

    private static String extension(String name){ int i=name.lastIndexOf('.'); return i>=0?name.substring(i):""; }

    private static byte[] readAll(Uri uri) throws Exception {
        ContentResolver cr = AppHolder.activity.getContentResolver();
        try(InputStream in=cr.openInputStream(uri); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            if(in==null) throw new Exception("cannot open input");
            byte[] buf=new byte[65536]; int n; while((n=in.read(buf))>=0) out.write(buf,0,n); return out.toByteArray();
        }
    }
    private void writeAll(Uri uri, byte[] data) throws Exception {
        try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){
            if(out==null) throw new Exception("cannot open output"); out.write(data); out.flush();
        }
    }

    private Uri createSiblingOutput(Uri tree, String original, String outExt) throws Exception {
        return createOutput(original, outExt, familyBase(original));
    }

    private Uri createOutput(String original, String outExt) throws Exception {
        return createOutput(original, outExt, familyBase(original));
    }

    private Uri createOutput(String original, String outExt, String family) throws Exception {
        Uri root=ensureOutputFolder();
        Uri folder=ensureChildFolder(root, safeFamily(family));
        String base=original; int dot=base.lastIndexOf('.'); if(dot>0) base=base.substring(0,dot);
        String candidate=base+outExt; int i=1;
        while (existsChild(folder,candidate)) candidate=base+" ("+(i++)+")"+outExt;
        Uri created=DocumentsContract.createDocument(getContentResolver(), folder, "application/octet-stream", candidate);
        if(created==null) throw new Exception("create output failed");
        return created;
    }

    private Uri ensureOutputFolder() throws Exception {
        String rootId=DocumentsContract.getTreeDocumentId(selectedTree);
        Uri rootDoc=DocumentsContract.buildDocumentUriUsingTree(selectedTree,rootId);
        Uri existing=findChild(rootDoc,"Samssz_Converted");
        if(existing!=null)return existing;
        Uri made=DocumentsContract.createDocument(getContentResolver(),rootDoc,DocumentsContract.Document.MIME_TYPE_DIR,"Samssz_Converted");
        if(made==null)throw new Exception("cannot create output folder");
        return made;
    }

    private Uri ensureChildFolder(Uri parent,String name) throws Exception {
        Uri existing=findChild(parent,name);
        if(existing!=null)return existing;
        Uri made=DocumentsContract.createDocument(getContentResolver(),parent,DocumentsContract.Document.MIME_TYPE_DIR,name);
        if(made==null)throw new Exception("cannot create family folder: "+name);
        return made;
    }

    private static String safeFamily(String family){
        String s=family==null?"Unknown":family.trim();
        if(s.isEmpty())s="Unknown";
        s=s.replaceAll("[\\/:*?\"<>|]","_");
        return s.length()>80?s.substring(0,80):s;
    }

    private static String familyBase(String filename){
        String s=filename; int dot=s.lastIndexOf('.'); if(dot>0)s=s.substring(0,dot);
        // Remove duplicate suffixes first.
        s=s.replaceFirst("(?i)\\s*\\(\\d+\\)$","");
        String old="";
        while(!s.equals(old)){
            old=s;
            s=s.replaceFirst("(?i)(?:[_+.-](?:hi|high|low|lo|med|medium|lod|lod0|lod1|lod2|lod3|vehicle|veh|vehhi|veh_hi|diffuse|diff|normal|norm|specular|spec|roughness|rough|metallic|metal|emissive|emit|collision|col|shadow|damage|broken|decal|texture|textures|interior|int|glass|wheel|wheels|light|lights))$","");
        }
        return s.isEmpty()?filename.substring(0,Math.max(1,dot>0?dot:filename.length())):s;
    }

    private boolean existsChild(Uri parent,String name){ return findChild(parent,name)!=null; }
    private Uri findChild(Uri parent,String wanted){
        String id=DocumentsContract.getDocumentId(parent);
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(parent,id);
        String[] proj={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME};
        try(android.database.Cursor c=getContentResolver().query(children,proj,null,null,null)){
            if(c==null)return null; int idIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID); int nameIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            while(c.moveToNext()){ if(wanted.equals(c.getString(nameIx))) return DocumentsContract.buildDocumentUriUsingTree(selectedTree,c.getString(idIx)); }
        }catch(Exception ignored){}
        return null;
    }

    private static boolean isArchiveExt(String ext){
        return ".zip".equals(ext)||".7z".equals(ext)||".rar".equals(ext)||".tar".equals(ext)||".gz".equals(ext)||".tgz".equals(ext)||".bz2".equals(ext)||".xz".equals(ext);
    }

    private int convertArchive(Uri uri,String archiveName,String ext){
        if(".zip".equals(ext)) return convertZip(uri,archiveName);
        // Android core can read ZIP directly. Other archive formats are detected
        // and reported instead of being silently treated as folders or RPFs.
        processConsoleLine("• "+archiveName+" detected ("+ext+") • extractor not bundled in this build");
        return 0;
    }

    private int convertZip(Uri zipUri,String archiveName) {
        int count=0;
        try(InputStream in=getContentResolver().openInputStream(zipUri)) {
            if(in==null) return 0;
            class EntryData { String name; String ext; byte[] data; EntryData(String n,String e,byte[] d){name=n;ext=e;data=d;} }
            ArrayList<EntryData> entries=new ArrayList<>();
            try(ZipInputStream zis=new ZipInputStream(in)) {
                ZipEntry e; byte[] buf=new byte[65536];
                while((e=zis.getNextEntry())!=null){
                    if(e.isDirectory())continue;
                    String name=e.getName(); String ext=extension(name.toLowerCase(Locale.ROOT));
                    if(!(PC_TO_PS4.containsKey(ext)||PS4_TO_PC.containsKey(ext)))continue;
                    ByteArrayOutputStream tmp=new ByteArrayOutputStream(); int n; while((n=zis.read(buf))>0)tmp.write(buf,0,n);
                    entries.add(new EntryData(new java.io.File(name).getName(),ext,tmp.toByteArray()));
                }
            }
            boolean hasPc=false;
            for(EntryData e:entries) if(PC_TO_PS4.containsKey(e.ext)) { hasPc=true; break; }
            for(EntryData e:entries){
                // If an archive contains PC resources, process only PC→PS4.
                // If it contains PS4 resources only, allow PS4→PC. This prevents
                // a mixed archive from generating a second reverse-converted set.
                boolean allowed=hasPc?PC_TO_PS4.containsKey(e.ext):PS4_TO_PC.containsKey(e.ext);
                if(!allowed)continue;
                try {
                    Uri out=createOutput(e.name,targetExt(e.ext),familyBase(e.name));
                    writeAll(out,ModelConverter.convert(e.data,e.ext));
                    count++; processConsoleLine("✓ "+archiveName+" :: "+e.name);
                } catch(Exception ex){ processConsoleLine("✕ "+archiveName+" :: "+e.name+" : "+ex.getMessage()); }
            }
        }catch(Exception ex){ processConsoleLine("ZIP ERROR "+archiveName+" : "+ex.getMessage()); }
        return count;
    }

    private List<DocumentNode> listTree(Uri tree) {
        List<DocumentNode> out=new ArrayList<>();
        crawl(tree,out,0);
        return out;
    }
    private void crawl(Uri parent,List<DocumentNode> out,int depth){
        if(depth>16)return;
        String docId=DocumentsContract.getTreeDocumentId(parent);
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(parent,docId);
        String[] proj={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_FLAGS};
        try(android.database.Cursor c=getContentResolver().query(children,proj,null,null,null)){
            if(c==null)return;
            int idIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            int mimeIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
            while(c.moveToNext()){
                String id=c.getString(idIx); String name=c.getString(nameIx); String mime=c.getString(mimeIx);
                Uri child=DocumentsContract.buildDocumentUriUsingTree(parent,id);
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) { if(!"Samssz_Converted".equalsIgnoreCase(name)) crawl(child,out,depth+1); } else out.add(new DocumentNode(name,child));
            }
        }catch(Exception e){ log("SCAN ERROR: "+e.getMessage()); }
    }

    private static class DocumentNode { final String name; final Uri uri; DocumentNode(String n,Uri u){name=n;uri=u;} }
    private static class AppHolder { static Activity activity; }
    @Override protected void onResume(){ super.onResume(); AppHolder.activity=this; }

    // Core converter mirrors the supplied Python Model Forge algorithm:
    // 16-byte RSC7 header + raw-deflate payload + GTAV1/PS4 byte replacement.
    private static class ModelConverter {
        static byte[] convert(byte[] data,String ext) throws Exception {
            String outExt = PC_TO_PS4.containsKey(ext) ? PC_TO_PS4.get(ext) : PS4_TO_PC.get(ext);
            if(outExt==null) throw new Exception("unsupported extension");
            if(!PATCH_EXTS.contains(ext) && !isPatchPs4(ext)) return Arrays.copyOf(data,data.length);
            if(data.length<4 || !(data[0]=='R'&&data[1]=='S'&&data[2]=='C'&&data[3]=='7')) return Arrays.copyOf(data,data.length);
            if(data.length<16) throw new Exception("RSC7 header truncated");
            byte[] header=Arrays.copyOfRange(data,0,16);
            byte[] comp=Arrays.copyOfRange(data,16,data.length);
            byte[] dec=inflateRaw(comp);
            byte[] gtav1=longLE(0x7755555555996996L);
            byte[] ps4=longLE(8598872888530528406L);
            boolean pc2ps4=PC_TO_PS4.containsKey(ext);
            byte[] from=pc2ps4?gtav1:ps4, to=pc2ps4?ps4:gtav1;
            int count=countSeq(dec,from);
            if(count>0) dec=replaceSeq(dec,from,to);
            byte[] raw=deflateRaw(dec);
            byte[] out=new byte[header.length+raw.length];
            System.arraycopy(header,0,out,0,header.length); System.arraycopy(raw,0,out,header.length,raw.length);
            return out;
        }
        static boolean isPatchPs4(String ext){ return ext.equals(".oft")||ext.equals(".odr")||ext.equals(".odd")||ext.equals(".opt")||ext.equals(".obn")||ext.equals(".obd"); }
        static byte[] longLE(long v){ byte[] b=new byte[8]; for(int i=0;i<8;i++)b[i]=(byte)(v>>(8*i)); return b; }
        static int countSeq(byte[] a,byte[] b){ int n=0; outer: for(int i=0;i<=a.length-b.length;i++){for(int j=0;j<b.length;j++)if(a[i+j]!=b[j])continue outer;n++;} return n; }
        static byte[] replaceSeq(byte[] a,byte[] from,byte[] to){ byte[] out=new byte[a.length]; int oi=0; for(int i=0;i<a.length;){boolean ok=i+from.length<=a.length; if(ok){for(int j=0;j<from.length;j++)if(a[i+j]!=from[j]){ok=false;break;}} if(ok){System.arraycopy(to,0,out,oi,to.length);oi+=to.length;i+=from.length;} else {out[oi++]=a[i++];}} return Arrays.copyOf(out,oi); }
        static byte[] inflateRaw(byte[] data) throws Exception { Inflater inf=new Inflater(true); inf.setInput(data); ByteArrayOutputStream out=new ByteArrayOutputStream(Math.max(1024,data.length*2)); byte[] buf=new byte[65536]; try{while(!inf.finished()){int n=inf.inflate(buf); if(n==0){if(inf.needsDictionary()) throw new Exception("deflate dictionary required"); if(inf.needsInput()) break;} out.write(buf,0,n);} if(!inf.finished()) throw new Exception("deflate stream incomplete"); return out.toByteArray();} finally{inf.end();}}
        static byte[] deflateRaw(byte[] data){ Deflater d=new Deflater(9,true); d.setInput(data); d.finish(); ByteArrayOutputStream out=new ByteArrayOutputStream(data.length/2+64); byte[] buf=new byte[65536]; while(!d.finished()){int n=d.deflate(buf); out.write(buf,0,n);} d.end(); return out.toByteArray(); }
    }
}

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SAMSSZ Mobile backend — non-interactive bridge to SamsszConverter.py + SamsszRenamer.py.

Keeps the same operation surface used by MainActivity:
  convert | extract | auto_scan | smart | pipeline | build_rpf | build_otd | rename

All interactive terminal prompts from the desktop toolkit are bypassed.
"""
from __future__ import annotations

import json
import os
import platform
import shutil
import struct
import sys
import tempfile
import traceback
import zipfile
from pathlib import Path

import SamsszConverter as sc

# ---------------------------------------------------------------------------
# Engine tables (exact structure from SamsszConverter.MODEL_ENGINE)
# ---------------------------------------------------------------------------
PC_TO_PS4 = sc.MODEL_ENGINE["PC_TO_PS4"]
PS4_TO_PC = sc.MODEL_ENGINE["PS4_TO_PC"]
MODEL_EXTS = set(PC_TO_PS4) | set(PS4_TO_PC)
PC_EXTS = set(PC_TO_PS4)
PS4_EXTS = set(PS4_TO_PC)

ARCHIVE_EXTS = {".zip", ".7z", ".rar", ".tar", ".tgz", ".gz", ".bz2", ".xz"}
SKIP_PARTS = {"Samssz_Converted", "Samssz_Auto_Workspace", "__pycache__", "Build", ".samssz_tmp"}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _files(root, *, recursive=True):
    """Return real input files; skip generated/cache trees."""
    root = Path(root)
    it = root.rglob("*") if recursive else root.glob("*")
    out = []
    for p in it:
        if not p.is_file():
            continue
        try:
            rel = p.relative_to(root)
        except ValueError:
            continue
        if any(part in SKIP_PARTS for part in rel.parts):
            continue
        if p.name.startswith(".samssz_"):
            continue
        out.append(p)
    return sorted(out, key=lambda x: x.relative_to(root).as_posix().lower())


def _model_candidates(root, direction="both"):
    out = []
    for p in _files(root):
        ext = p.suffix.lower()
        if ext not in MODEL_EXTS:
            continue
        if direction == "pc2ps4" and ext not in PC_EXTS:
            continue
        if direction == "ps42pc" and ext not in PS4_EXTS:
            continue
        out.append(p)
    return out


def _out_suffix(ext):
    cfg = PC_TO_PS4.get(ext) or PS4_TO_PC.get(ext)
    if not cfg:
        return None
    return cfg["out"] if isinstance(cfg, dict) else cfg


def _convert_file(p, direction=None):
    """Run MODEL_ENGINE process_file; return True on success."""
    ext = p.suffix.lower()
    if direction == "pc2ps4" and ext not in PC_EXTS:
        return False
    if direction == "ps42pc" and ext not in PS4_EXTS:
        return False
    try:
        return bool(sc.MODEL_ENGINE["process_file"](str(p), 0))
    except Exception:
        return False


def _safe_rel(p, root):
    try:
        return str(p.relative_to(root))
    except Exception:
        return str(p)


# ---------------------------------------------------------------------------
# CONVERT
# ---------------------------------------------------------------------------
def convert_models(root, direction="both"):
    root = Path(root)
    candidates = _model_candidates(root, direction)
    ok, fail = [], []
    for p in candidates:
        rel = _safe_rel(p, root)
        try:
            if _convert_file(p, direction):
                ok.append(rel)
            else:
                fail.append(rel)
        except Exception as e:
            fail.append(f"{rel} :: {e}")
    return {
        "operation": "convert",
        "detected": len(candidates),
        "processed": len(candidates),
        "success": len(ok),
        "failed": len(fail),
        "found": [_safe_rel(p, root) for p in candidates],
        "ok": ok,
        "fail": fail,
    }


# ---------------------------------------------------------------------------
# EXTRACT
# ---------------------------------------------------------------------------
def extract_rpf_one(src, dest):
    eng = sc.load_rpf_engine()
    eng["extract"](str(src), str(dest))


def extract_all(root):
    """Extract every .rpf and .ytd under root (recursive, skip generated trees).

    RPF  → folder next to archive (or name_extracted if collision)
    YTD  → folder of DDS textures via embedded YTD_ENGINE (pure Python, any size)
    """
    root = Path(root)
    results = []
    targets = [p for p in _files(root) if p.suffix.lower() in {".rpf", ".ytd"}]
    if not targets:
        return {
            "operation": "extract",
            "results": [],
            "count": 0,
            "message": "No .rpf / .ytd found in selected folder.",
        }

    for p in targets:
        ext = p.suffix.lower()
        try:
            d = p.with_suffix("")
            if d.exists() and not d.is_dir():
                d = Path(str(d) + "_extracted")
            elif d.exists() and d.is_dir() and any(d.iterdir()):
                # avoid mixing with previous partial extract
                n = 1
                while Path(f"{d}_{n}").exists():
                    n += 1
                d = Path(f"{d}_{n}")
            d.mkdir(parents=True, exist_ok=True)

            if ext == ".rpf":
                extract_rpf_one(p, d)
                nfiles = sum(1 for _ in d.rglob("*") if _.is_file())
                results.append(
                    {
                        "type": "rpf",
                        "src": _safe_rel(p, root),
                        "dest": _safe_rel(d, root),
                        "files": nfiles,
                        "ok": True,
                    }
                )
            elif ext == ".ytd":
                sc.YTD_ENGINE["extract_ytd"](str(p), str(d))
                ndds = sum(1 for _ in d.rglob("*.dds") if _.is_file())
                results.append(
                    {
                        "type": "ytd",
                        "src": _safe_rel(p, root),
                        "dest": _safe_rel(d, root),
                        "dds": ndds,
                        "ok": True,
                    }
                )
        except Exception as e:
            results.append(
                {
                    "type": ext.lstrip(".") or "file",
                    "src": _safe_rel(p, root),
                    "ok": False,
                    "error": str(e),
                }
            )

    ok = sum(1 for r in results if r.get("ok"))
    fail = len(results) - ok
    return {
        "operation": "extract",
        "results": results,
        "count": len(results),
        "success": ok,
        "failed": fail,
    }


# ---------------------------------------------------------------------------
# RPF targeting (same rules as desktop AUTO SCAN)
# ---------------------------------------------------------------------------
def _is_dlc(p):
    try:
        return sc._is_dlc_rpf_name(p)
    except Exception:
        n = p.name.lower()
        return n.startswith("dlc") and n.endswith(".rpf")


def _is_vehicles(p):
    try:
        return sc._is_vehicles_rpf_name(p)
    except Exception:
        return p.name.lower() == "vehicles.rpf"


def _target_rpfs(root):
    rpfs = [p for p in Path(root).rglob("*.rpf") if p.is_file()]
    veh = [p for p in rpfs if _is_vehicles(p)]
    dlc = [p for p in rpfs if _is_dlc(p)]
    return sorted(set(veh or dlc), key=lambda x: str(x).lower())


def _zip_extract(src, dst):
    dst = Path(dst)
    dst.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(src, "r") as z:
        for i in z.infolist():
            name = Path(i.filename)
            if name.is_absolute() or ".." in name.parts:
                continue
            out = (dst / name).resolve()
            if not str(out).startswith(str(dst.resolve())):
                continue
            if i.is_dir():
                out.mkdir(parents=True, exist_ok=True)
            else:
                out.parent.mkdir(parents=True, exist_ok=True)
                with z.open(i) as a, open(out, "wb") as b:
                    shutil.copyfileobj(a, b)


def _extract_archive(archive, dest):
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    suf = archive.suffix.lower()
    if suf == ".zip":
        _zip_extract(archive, dest)
        return True, "zip"
    try:
        ok, detail = sc._auto_extract_archive(archive, dest)
        return ok, detail
    except Exception as e:
        return False, str(e)


def _process_rpf_workspace(rpf, workspace, generated, report, tag):
    """Extract RPF → convert PC models → extract YTD. Append to generated list."""
    tw = workspace / f"rpf_{abs(hash(str(rpf))) % 1_000_000_000}"
    tw.mkdir(parents=True, exist_ok=True)
    try:
        extract_rpf_one(rpf, tw)
        made = 0
        for p in [x for x in _files(tw) if x.suffix.lower() in PC_EXTS]:
            if _convert_file(p, "pc2ps4"):
                out_suf = _out_suffix(p.suffix.lower())
                result = p.with_suffix(out_suf) if out_suf else p
                if result.is_file() and result.stat().st_size > 0:
                    generated.append(result)
                    made += 1
                elif p.is_file():
                    # process_file may write in-place under new suffix
                    cand = p.with_suffix(out_suf) if out_suf else None
                    if cand and cand.is_file():
                        generated.append(cand)
                        made += 1
        for ytd in [x for x in _files(tw) if x.suffix.lower() == ".ytd"]:
            try:
                d = ytd.with_suffix("")
                sc.YTD_ENGINE["extract_ytd"](str(ytd), str(d))
                # Prefer converted OTD next to ytd if pipeline produced it
                otd = ytd.with_suffix(".otd")
                if otd.is_file() and otd.stat().st_size > 0:
                    generated.append(otd)
                    made += 1
            except Exception as e:
                report.append({"tag": tag, "ytd": ytd.name, "error": str(e)})
        return made
    except Exception as e:
        report.append({"tag": tag, "rpf": str(rpf), "error": str(e)})
        return 0


# ---------------------------------------------------------------------------
# AUTO SCAN (ZIP/7Z/RAR + loose vehicles/dlc RPF)
# ---------------------------------------------------------------------------
def auto_scan(root):
    root = Path(root)
    workspace = Path(tempfile.mkdtemp(prefix="samssz_mobile_auto_"))
    generated = []
    report = []
    try:
        archives = [p for p in _files(root) if p.suffix.lower() in ARCHIVE_EXTS]
        loose = [p for p in _files(root) if p.suffix.lower() == ".rpf"]

        for idx, a in enumerate(archives):
            aw = workspace / f"archive_{idx}"
            aw.mkdir(parents=True, exist_ok=True)
            try:
                ok, detail = _extract_archive(a, aw)
                if not ok:
                    report.append({"archive": _safe_rel(a, root), "skip": detail})
                    continue
                targets = _target_rpfs(aw)
                if not targets:
                    report.append(
                        {
                            "archive": _safe_rel(a, root),
                            "skip": "no vehicles.rpf / dlc-style RPF",
                        }
                    )
                    continue
                for rpf in targets:
                    _process_rpf_workspace(
                        rpf, workspace, generated, report, f"{a.name}::{rpf.name}"
                    )
            except Exception as e:
                report.append({"archive": _safe_rel(a, root), "error": str(e)})

        target_set = {x.resolve() for x in _target_rpfs(root)}
        for rpf in loose:
            if rpf.resolve() not in target_set:
                continue
            _process_rpf_workspace(
                rpf, workspace, generated, report, _safe_rel(rpf, root)
            )

        # Also convert loose PC models / YTD sitting in the folder
        for p in _files(root):
            ext = p.suffix.lower()
            try:
                if ext in PC_EXTS:
                    if _convert_file(p, "pc2ps4"):
                        out_suf = _out_suffix(ext)
                        result = p.with_suffix(out_suf) if out_suf else p
                        if result.is_file():
                            generated.append(result)
                elif ext == ".ytd":
                    d = p.with_suffix("")
                    sc.YTD_ENGINE["extract_ytd"](str(p), str(d))
                    otd = p.with_suffix(".otd")
                    if otd.is_file() and otd.stat().st_size > 0:
                        generated.append(otd)
            except Exception as e:
                report.append({"file": _safe_rel(p, root), "error": str(e)})

        # Dedupe by resolved path
        uniq = []
        seen = set()
        for p in generated:
            if not p.is_file() or p.stat().st_size <= 0:
                continue
            key = str(p.resolve())
            if key in seen:
                continue
            seen.add(key)
            uniq.append(p)

        outdir = root / "Samssz_Converted" / "AUTO_SCAN"
        outdir.mkdir(parents=True, exist_ok=True)
        published = []
        for p in uniq:
            try:
                fam = sc._smart_model_base(p.stem)
            except Exception:
                fam = p.stem
            fd = outdir / fam
            fd.mkdir(parents=True, exist_ok=True)
            dst = fd / p.name
            if dst.exists():
                stem, suf = p.stem, p.suffix
                n = 1
                while dst.exists():
                    dst = fd / f"{stem}({n}){suf}"
                    n += 1
            shutil.copy2(p, dst)
            published.append(dst)

        return {
            "operation": "auto_scan",
            "generated": [_safe_rel(p, root) for p in published],
            "count": len(published),
            "report": report,
        }
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


# ---------------------------------------------------------------------------
# BUILD RPF (unencrypted RPF7 — mobile-safe pure Python)
# ---------------------------------------------------------------------------
def build_rpf(root):
    root = Path(root)
    outdir = root / "Build"
    outdir.mkdir(exist_ok=True)
    files = [
        p
        for p in root.rglob("*")
        if p.is_file() and outdir not in p.parents and p != outdir
    ]
    if not files:
        raise RuntimeError("Build folder is empty.")

    class E:
        def __init__(self, typ, name, parent=None):
            self.typ = typ
            self.name = name
            self.parent = parent
            self.children = []
            self.data = None
            self.path = None
            self.index = 0

    root_e = E("dir", "")
    dirs = {"": root_e}
    for p in sorted(files, key=lambda x: x.relative_to(root).as_posix().lower()):
        rel = p.relative_to(root).as_posix()
        parts = rel.split("/")
        cur = ""
        parent = root_e
        for part in parts[:-1]:
            cur = f"{cur}/{part}".strip("/")
            if cur not in dirs:
                d = E("dir", part, parent)
                parent.children.append(d)
                dirs[cur] = d
            parent = dirs[cur]
        f = E("file", parts[-1], parent)
        f.path = p
        parent.children.append(f)

    entries = []

    def flatten(d):
        d.index = len(entries)
        entries.append(d)
        for c in sorted(d.children, key=lambda x: (x.typ != "dir", x.name.lower())):
            flatten(c)

    flatten(root_e)
    for i, e in enumerate(entries):
        e.index = i

    names = bytearray(b"\0")
    name_off = {}
    for e in entries:
        if e.name and e.name not in name_off:
            name_off[e.name] = len(names)
            names.extend(e.name.encode("utf-8", "replace") + b"\0")

    def len_subtree(d):
        n = 0

        def count(x):
            nonlocal n
            for c in x.children:
                n += 1
                if c.typ == "dir":
                    count(c)

        count(d)
        return n

    def span(d):
        if not d.children:
            return (d.index + 1, 0)
        return (d.children[0].index, len_subtree(d))

    # First pass: sizes only (do not load whole tree into RAM).
    table = bytearray()
    file_sizes = []
    for e in entries:
        if e.typ == "dir":
            idx, cnt = span(e)
            table.extend(struct.pack("<II", name_off.get(e.name, 0), 0x7FFFFF00))
            table.extend(struct.pack("<II", idx, cnt))
        else:
            sz = e.path.stat().st_size
            if sz > 0xFFFFFF:
                raise RuntimeError(
                    f"RPF entry too large for unencrypted RPF7 size field (24-bit): {e.name} ({sz} bytes)"
                )
            file_sizes.append(sz)
            e.data = None  # streamed later
            table.extend(struct.pack("<H", name_off[e.name]))
            table.extend(bytes([sz & 255, (sz >> 8) & 255, (sz >> 16) & 255]))
            table.extend(struct.pack("<I", 0))
            table.extend(struct.pack("<II", sz, 0))

    header_len = 16 + len(table) + len(names)
    data_start = (header_len + 511) // 512 * 512
    first_sector = data_start // 512

    # Compute sector offsets without buffering every file.
    off = 0
    cursor = 0  # payload bytes written so far (excluding final padding to sector)
    sector_for_file = []
    for e in entries:
        if e.typ == "file":
            pad = (512 - (cursor % 512)) % 512
            cursor += pad
            sector_for_file.append(first_sector + cursor // 512)
            cursor += e.path.stat().st_size
            table[off + 5 : off + 8] = bytes(
                [
                    sector_for_file[-1] & 255,
                    (sector_for_file[-1] >> 8) & 255,
                    (sector_for_file[-1] >> 16) & 255,
                ]
            )
            off += 16
        else:
            off += 16

    out = outdir / (root.name + ".rpf")
    with open(out, "wb") as f:
        f.write(struct.pack("<IIII", 0x52504637, len(entries), len(names), 0x4E45504F))
        f.write(table)
        f.write(names)
        f.write(b"\0" * (data_start - (16 + len(table) + len(names))))
        # Stream each file into the payload region (1 MiB chunks).
        bufsize = 1024 * 1024
        for e in entries:
            if e.typ != "file":
                continue
            # pad to sector boundary
            pos = f.tell()
            pad = (512 - (pos % 512)) % 512
            if pad:
                f.write(b"\0" * pad)
            with open(e.path, "rb") as src:
                while True:
                    chunk = src.read(bufsize)
                    if not chunk:
                        break
                    f.write(chunk)
    return {
        "operation": "build_rpf",
        "output": _safe_rel(out, root),
        "files": len(files),
    }


# ---------------------------------------------------------------------------
# SMART MOD BUILDER
# ---------------------------------------------------------------------------
def smart(root, mode="keep"):
    root = Path(root)
    work = Path(tempfile.mkdtemp(prefix="samssz_mobile_smart_"))
    generated = []
    sources = []
    report = []
    try:
        loose = [
            p
            for p in _files(root)
            if p.suffix.lower() in MODEL_EXTS or p.suffix.lower() == ".ytd"
        ]
        for p in loose:
            ext = p.suffix.lower()
            try:
                if ext in MODEL_EXTS:
                    direction = "pc2ps4" if ext in PC_EXTS else "ps42pc"
                    if _convert_file(p, direction):
                        out_suf = _out_suffix(ext)
                        outp = p.with_suffix(out_suf) if out_suf else p
                        if outp.is_file() and outp.stat().st_size > 0:
                            generated.append(outp)
                            sources.append(p)
                elif ext == ".ytd":
                    d = p.with_suffix("")
                    sc.YTD_ENGINE["extract_ytd"](str(p), str(d))
                    sources.append(p)
                    otd = p.with_suffix(".otd")
                    if otd.is_file() and otd.stat().st_size > 0:
                        generated.append(otd)
            except Exception as e:
                report.append({"file": _safe_rel(p, root), "error": str(e)})

        for rpf in _target_rpfs(root):
            _process_rpf_workspace(
                rpf, work, generated, report, _safe_rel(rpf, root)
            )
            sources.append(rpf)

        outdir = root / "Samssz_Converted"
        outdir.mkdir(exist_ok=True)
        published = []
        for p in generated:
            if not p.is_file() or p.stat().st_size <= 0:
                continue
            try:
                fam = sc._smart_model_base(p.stem)
            except Exception:
                fam = p.stem
            fd = outdir / fam
            fd.mkdir(parents=True, exist_ok=True)
            dst = fd / p.name
            if dst.exists():
                stem, suf = p.stem, p.suffix
                n = 1
                while dst.exists():
                    dst = fd / f"{stem}({n}){suf}"
                    n += 1
            shutil.copy2(p, dst)
            published.append(dst)

        zips = []
        if mode in ("zipask", "purge"):
            groups = {}
            for p in published:
                try:
                    key = sc._smart_model_base(p.stem)
                except Exception:
                    key = p.stem
                groups.setdefault(key, []).append(p)
            for fam, items in groups.items():
                z = outdir / f"({fam})NAMA MOD.zip"
                try:
                    sc.smart_zip_family_outputs(items, z, fam)
                    zips.append(z)
                except Exception as e:
                    report.append({"zip": fam, "error": str(e)})

        if mode in ("purge", "props"):
            for s in sources:
                if s.is_file() and s.suffix.lower() in (MODEL_EXTS | {".ytd", ".rpf"}):
                    try:
                        s.unlink()
                    except Exception:
                        pass

        return {
            "operation": "smart",
            "published": [_safe_rel(p, root) for p in published],
            "zips": [_safe_rel(z, root) for z in zips],
            "sources": [_safe_rel(s, root) for s in sources if s.exists()],
            "purged": mode in ("purge", "props"),
            "report": report,
        }
    finally:
        shutil.rmtree(work, ignore_errors=True)


# ---------------------------------------------------------------------------
# OTD BUILD (YTD → DDS → OTD via embedded RageBuilder)
# ---------------------------------------------------------------------------

def _runtime_roots(root):
    roots = []
    env = os.environ.get("SAMSSZ_OTD_RUNTIME", "")
    candidates = [
        Path(env) if env else None,
        Path.home() / ".samssz_otd_runtime",
        Path(root) / "otd_runtime",
        Path(__file__).resolve().parent.parent / "otd_runtime",  # unlikely on Android
        Path("/data/data/com.samssz.mobile/files/otd_runtime"),
        Path("/data/data/com.termux/files/home"),
    ]
    for p in candidates:
        if p is None:
            continue
        try:
            if str(p) and p.exists() and p.is_dir() and p not in roots:
                roots.append(p)
        except Exception:
            pass
    return roots


def _find_exec(names, roots):
    for r in roots:
        for name in names:
            d = r / name
            try:
                if d.is_file() and os.access(d, os.X_OK):
                    return d
            except Exception:
                pass
            try:
                for p in r.rglob(name):
                    if p.is_file() and os.access(p, os.X_OK):
                        return p
            except Exception:
                pass
    for name in names:
        q = shutil.which(name)
        if q:
            return Path(q)
    return None


def _stage_builder_assets(target_dir):
    """Copy embedded RageBuilder payload to a writable directory (large-file safe)."""
    target_dir = Path(target_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    names = ["ragebuilder.exe", "texture_builder.lua", "xg.dll", "zlib.dll", "zlib1.dll"]
    here = Path(getattr(sc, "_RUNTIME_DIR", Path(sc.__file__).resolve().parent))
    # Prefer pre-shipped otd_runtime/builder next to workspace copies
    shipped = []
    for root in [
        Path(__file__).resolve().parent.parent.parent.parent / "otd_runtime" / "builder",
        Path.cwd() / "otd_runtime" / "builder",
    ]:
        if root.is_dir():
            shipped.append(root)
    sources = {}
    for n in names:
        for root in shipped + [here]:
            cand = root / n
            if cand.is_file():
                sources[n] = cand
                break
    missing = [n for n in names if n not in sources]
    if missing:
        raise RuntimeError("OTD builder assets missing: " + ", ".join(missing))
    for n, src in sources.items():
        dst = target_dir / n
        if not dst.is_file() or dst.stat().st_size != src.stat().st_size:
            shutil.copy2(src, dst)
    return {n: target_dir / n for n in names}


def _run_ragebuilder(builder_dir, dds_folder, final_otd, launcher):
    """
    Invoke ragebuilder the same way desktop OTD_ENGINE does, via xow64 or wine.
    Streams work on disk; supports multi-hundred-MB texture folders.
    """
    import subprocess

    builder_dir = Path(builder_dir).resolve()
    dds_folder = Path(dds_folder).resolve()
    final_otd = Path(final_otd).resolve()
    final_otd.parent.mkdir(parents=True, exist_ok=True)

    # Prepare texture_input next to ragebuilder (Lua expects this name)
    tex_in = builder_dir / "texture_input"
    if tex_in.exists():
        shutil.rmtree(tex_in, ignore_errors=True)
    tex_in.mkdir(parents=True, exist_ok=True)

    # Copy DDS files with streaming (no full RAM load)
    buf = 1024 * 1024
    dds_count = 0
    for src in sorted(dds_folder.rglob("*.dds")):
        if not src.is_file():
            continue
        dst = tex_in / src.name
        # unique name if collision
        if dst.exists():
            stem, suf = src.stem, src.suffix
            i = 1
            while dst.exists():
                dst = tex_in / f"{stem}_{i}{suf}"
                i += 1
        with open(src, "rb") as a, open(dst, "wb") as b:
            while True:
                chunk = a.read(buf)
                if not chunk:
                    break
                b.write(chunk)
        dds_count += 1
    if dds_count == 0:
        raise RuntimeError(f"No DDS files under {dds_folder}")

    local_output = builder_dir / "texture.otd"
    if local_output.exists():
        local_output.unlink()

    env = os.environ.copy()
    env["WINEDEBUG"] = "-all"
    env["BOX64_LOG"] = "0"
    env["BOX64_NOBANNER"] = "1"

    launcher = Path(launcher)
    mode = launcher.name.lower()
    if mode == "xow64" or "xow64" in str(launcher):
        # xow64 r ragebuilder.exe texture_builder.lua
        cmd = [str(launcher), "r", "ragebuilder.exe", "texture_builder.lua"]
        cwd = str(builder_dir)
    else:
        # wine / wine64
        cmd = [str(launcher), "ragebuilder.exe", "texture_builder.lua"]
        cwd = str(builder_dir)

    # Also support OTD_ENGINE main() path which uses HOME/.xow64_wine
    # Prefer direct cwd execution of staged files.
    proc = subprocess.run(
        cmd,
        cwd=cwd,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=60 * 60,  # up to 1 hour for huge texture sets
    )
    log = (proc.stdout or b"").decode("utf-8", "replace")[-4000:]

    if not local_output.is_file() or local_output.stat().st_size <= 0:
        # Fallback: original OTD_ENGINE entry (uses WINE_C paths)
        old = list(sys.argv)
        sys.argv = ["build_otd.py", str(dds_folder), str(final_otd)]
        try:
            rc = sc.OTD_ENGINE["main"]()
        finally:
            sys.argv = old
        if final_otd.is_file() and final_otd.stat().st_size > 0:
            return True, f"OTD_ENGINE main ok rc={rc}"
        raise RuntimeError(
            f"ragebuilder did not produce texture.otd (exit={proc.returncode}).\n{log}"
        )

    # Stream copy output to final path
    with open(local_output, "rb") as a, open(final_otd, "wb") as b:
        while True:
            chunk = a.read(buf)
            if not chunk:
                break
            b.write(chunk)

    # Cleanup temp builder outputs (keep exe/dlls)
    try:
        local_output.unlink(missing_ok=True)
    except Exception:
        pass
    shutil.rmtree(tex_in, ignore_errors=True)
    return True, f"ok dds={dds_count} size={final_otd.stat().st_size} exit={proc.returncode}"


def build_otd(root):
    """
    YTD → DDS → OTD for every .ytd under root.
    Designed for large inputs (100MB–several GB texture sets):
      - one YTD at a time
      - disk streaming only
      - temp DDS removed after each success
    Requires a working xow64 or wine launcher on PATH / otd_runtime.
    """
    root = Path(root)
    ytds = [p for p in _files(root) if p.suffix.lower() == ".ytd"]
    if not ytds:
        raise RuntimeError("OTD: 0 .YTD detected.")

    # Stage builder next to outputs so large work stays on same volume
    builder_dir = root / "otd_runtime" / "builder"
    assets = _stage_builder_assets(builder_dir)

    roots = _runtime_roots(root)
    # Prefer explicit launchers
    xow = _find_exec(["xow64"], roots)
    wine = _find_exec(["wine64", "wine"], roots)
    box64 = _find_exec(["box64"], roots)

    launcher = None
    if xow:
        launcher = xow
    elif wine:
        launcher = wine
    elif box64 and wine:
        launcher = wine

    if launcher is None and platform.system() != "Windows":
        # Last chance: OTD_ENGINE on Windows PE host
        raise RuntimeError(
            "OTD runtime not ready. Install xow64/Wine+Box64 into otd_runtime/ "
            "(see otd_runtime/README.md). Builder assets are staged at: "
            + str(builder_dir)
        )

    # Expose runtime for OTD_ENGINE fallback
    old_home = os.environ.get("HOME")
    old_path = os.environ.get("PATH", "")
    old_runtime = os.environ.get("SAMSSZ_RUNTIME_DIR")
    candidate = roots[0] if roots else builder_dir
    try:
        os.environ["HOME"] = str(candidate if candidate.is_dir() else Path.home())
        os.environ["SAMSSZ_RUNTIME_DIR"] = str(builder_dir)
        os.environ["PATH"] = (
            str(builder_dir)
            + os.pathsep
            + str(Path(candidate) / "bin")
            + os.pathsep
            + old_path
        )
        if launcher and launcher.is_file():
            try:
                launcher.chmod(launcher.stat().st_mode | 0o111)
            except OSError:
                pass

        outdir = root / "Build"
        outdir.mkdir(parents=True, exist_ok=True)
        built = []
        errors = []

        for ytd in ytds:
            dds_dir = ytd.with_suffix("")  # folder next to ytd
            final = outdir / (ytd.stem + ".otd")
            try:
                # Extract YTD → DDS (stdlib engine; streams internally)
                if dds_dir.exists() and not any(dds_dir.rglob("*.dds")):
                    shutil.rmtree(dds_dir, ignore_errors=True)
                sc.YTD_ENGINE["extract_ytd"](str(ytd), str(dds_dir))
                dds_files = list(Path(dds_dir).rglob("*.dds"))
                if not dds_files:
                    raise RuntimeError("No DDS extracted from YTD")

                if platform.system() == "Windows":
                    old = list(sys.argv)
                    sys.argv = ["build_otd.py", str(dds_dir), str(final)]
                    try:
                        rc = sc.OTD_ENGINE["main"]()
                    finally:
                        sys.argv = old
                    if rc != 0 or not final.is_file() or final.stat().st_size <= 0:
                        raise RuntimeError(f"RageBuilder returned {rc}")
                    ok_msg = f"windows main size={final.stat().st_size}"
                else:
                    ok, ok_msg = _run_ragebuilder(builder_dir, dds_dir, final, launcher)

                if not final.is_file() or final.stat().st_size <= 0:
                    raise RuntimeError("OTD output missing after build")

                built.append(
                    {
                        "ytd": _safe_rel(ytd, root),
                        "otd": _safe_rel(final, root),
                        "size": final.stat().st_size,
                        "detail": ok_msg,
                    }
                )
            except Exception as e:
                errors.append({"ytd": _safe_rel(ytd, root), "error": str(e)})
            finally:
                # Free disk after each YTD (critical for 100MB+ packs)
                shutil.rmtree(dds_dir, ignore_errors=True)

        result = {
            "operation": "build_otd",
            "detected": len(ytds),
            "success": len(built),
            "failed": len(errors),
            "built": built,
            "errors": errors,
            "builder": str(builder_dir),
            "launcher": str(launcher) if launcher else "windows-native",
        }
        if errors and not built:
            raise RuntimeError("OTD builder failed: " + json.dumps(result, ensure_ascii=False))
        return result
    finally:
        if old_home is None:
            os.environ.pop("HOME", None)
        else:
            os.environ["HOME"] = old_home
        os.environ["PATH"] = old_path
        if old_runtime is None:
            os.environ.pop("SAMSSZ_RUNTIME_DIR", None)
        else:
            os.environ["SAMSSZ_RUNTIME_DIR"] = old_runtime


def rename_family(root, old_name, new_name):
    """Non-interactive family rename matching SamsszRenamer.py behaviour."""
    root = Path(root)
    old_name = (old_name or "").strip()
    new_name = (new_name or "").strip()
    if not old_name:
        raise RuntimeError("old_name is required")
    if not new_name or any(c in new_name for c in ("/", "\\", "\0")):
        raise RuntimeError("new_name is invalid")

    family = []
    for p in root.iterdir():
        if not p.is_file():
            continue
        if p.suffix.lower() not in (".oft", ".otd"):
            continue
        root_stem = _family_root(p.stem)
        if p.stem == old_name or root_stem == old_name:
            family.append(p)
    family = sorted(family, key=lambda x: x.name.lower())
    if not family:
        raise RuntimeError(f"No .oft/.otd family found for: {old_name}")

    zips = [
        p
        for p in root.iterdir()
        if p.is_file() and p.suffix.lower() == ".zip" and _zip_matches(p, old_name)
    ]

    plan = []
    sources = {p.resolve() for p in family}
    for src in family:
        r = _family_root(src.stem)
        tail = src.stem[len(r) :] if src.stem != r else ""
        dst = src.with_name(new_name + tail + src.suffix.lower())
        if dst.exists() and dst.resolve() not in sources:
            raise RuntimeError(f"Target already exists: {dst.name}")
        plan.append((src, dst))

    renamed = []
    temps = []
    for i, (src, dst) in enumerate(plan):
        tmp = src.with_name(f".samssz_rename_tmp_{os.getpid()}_{i}{src.suffix}")
        src.rename(tmp)
        temps.append((tmp, dst))
    for tmp, dst in temps:
        tmp.rename(dst)
        renamed.append(dst.name)

    zip_out = []
    for zp in zips:
        _rename_zip_contents(zp, old_name, new_name)
        target = zp.with_name(f"({new_name}){old_name}.zip")
        if target != zp:
            if target.exists():
                raise RuntimeError(f"ZIP target already exists: {target.name}")
            zp.rename(target)
        zip_out.append(target.name)

    return {
        "operation": "rename",
        "old": old_name,
        "new": new_name,
        "renamed": renamed,
        "zips": zip_out,
        "count": len(renamed),
    }


# ---------------------------------------------------------------------------
# ENTRY
# ---------------------------------------------------------------------------
def run(root, operation, mode="keep", direction="both", old_name="", new_name=""):
    """
    Main entry called from Java/Chaquopy.

    Extra kwargs old_name/new_name are optional for rename operation.
    """
    root = Path(root)
    try:
        if operation == "convert":
            return convert_models(root, direction)
        if operation == "extract":
            return extract_all(root)
        if operation == "auto_scan":
            return auto_scan(root)
        if operation == "smart":
            return smart(root, mode)
        if operation == "pipeline":
            ex = extract_all(root)
            sm = smart(root, "keep")
            return {"operation": "pipeline", "extract": ex, "smart": sm}
        if operation == "build_rpf":
            return build_rpf(root)
        if operation == "build_otd":
            return build_otd(root)
        if operation == "rename":
            return rename_family(root, old_name, new_name)
        raise ValueError("Unknown operation: " + str(operation))
    except Exception as e:
        return {
            "operation": operation,
            "ok": False,
            "error": str(e),
            "traceback": traceback.format_exc()[-2000:],
        }

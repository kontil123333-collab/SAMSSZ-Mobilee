#!/data/data/com.termux/files/usr/bin/bash
# Jalankan di Termux:
#   bash 02_hubungkan_ke_folder_mod.sh /storage/emulated/0/Download/MyMod
set -e
MOD="${1:-}"
if [ -z "$MOD" ]; then
  echo "Pakai: $0 /path/ke/folder_mod"
  exit 1
fi
if [ ! -d "$MOD" ]; then
  echo "Folder tidak ada: $MOD"
  exit 1
fi
if [ ! -x "$HOME/xow64" ]; then
  echo "xow64 belum terpasang. Jalankan dulu 01_install_termux.sh"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
KIT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
BUILDER_SRC="$KIT_DIR/otd_runtime/builder"

mkdir -p "$MOD/otd_runtime/builder"
cp -f "$HOME/xow64" "$MOD/otd_runtime/xow64"
chmod +x "$MOD/otd_runtime/xow64"

if [ -d "$BUILDER_SRC" ]; then
  cp -f "$BUILDER_SRC/"* "$MOD/otd_runtime/builder/"
  echo "Builder OTD disalin ke $MOD/otd_runtime/builder/"
else
  echo "PERINGATAN: folder builder tidak ditemukan di kit. App akan stage sendiri saat build."
fi

echo "=== Struktur otd_runtime ==="
ls -la "$MOD/otd_runtime/"
ls -la "$MOD/otd_runtime/builder/" 2>/dev/null || true
echo "=== SIAP. Buka SAMSSZ Mobile → pilih folder: $MOD → Build OTD ==="

local ROOT = "texture_input/"

print("======================================")
print("         ORBIS TEXTURE BUILDER        ")
print("======================================")
set_platform("orbis")
print("Scanning textures folder...")
local texture_count = load_textures(ROOT)
if texture_count and texture_count >= 1 then
    print("Loaded " .. texture_count .. " texture(s) successfully.")
    print("Building texture dictionary...")

    save_texture_dictionary("texture", "")

    print("Texture dictionary created successfully.")
else
    print("No textures found. Aborting build process.")
end

# SAMSSZ OTD Runtime (Android / ARM64)

OTD build = **YTD → DDS → ragebuilder.exe → .otd**

`ragebuilder.exe` is Windows x86-64. On Android ARM64 it needs a launcher:

| Launcher | Recommended |
|----------|-------------|
| **xow64** | Yes (Wine-WoW64 + Box64) |
| wine64 / wine + box64 | OK |

## Quick setup (Termux — once)

```bash
pkg install wget
cd $HOME && wget -O xow64 https://github.com/ar37-rs/xow64-wine/raw/refs/heads/main/xow64
chmod +x ~/xow64
~/xow64 install
```

Then copy or symlink into the **selected workspace**:

```text
<folder yang dipilih di SAMSSZ>/otd_runtime/xow64
```

or put the whole Wine prefix under:

```text
<folder>/otd_runtime/
```

Builder binaries are auto-staged to:

```text
<folder>/otd_runtime/builder/
  ragebuilder.exe
  texture_builder.lua
  xg.dll  zlib.dll  zlib1.dll
```

## Large files (100MB+)

Pipeline processes **one YTD at a time**, streams DDS on disk, deletes temp DDS after each success. No artificial size limit; free storage must hold peak temp (~1–2× YTD size).

## Success rule

Build is OK only when `Build/<name>.otd` exists and size > 0.

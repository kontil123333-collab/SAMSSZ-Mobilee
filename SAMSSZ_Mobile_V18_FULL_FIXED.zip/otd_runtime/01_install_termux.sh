#!/data/data/com.termux/files/usr/bin/bash
# Jalankan di Termux: bash 01_install_termux.sh
set -e
echo "=== SAMSSZ: install xow64 ==="
pkg update -y
pkg upgrade -y
pkg install wget curl -y

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
if [ -f "$SCRIPT_DIR/xow64" ]; then
  cp -f "$SCRIPT_DIR/xow64" "$HOME/xow64"
else
  cd "$HOME"
  wget -O xow64 https://github.com/ar37-rs/xow64-wine/raw/refs/heads/main/xow64
fi
chmod +x "$HOME/xow64"
echo "=== Menjalankan ~/xow64 install (bisa lama) ==="
"$HOME/xow64" install
echo "=== Cek Wine ==="
"$HOME/xow64" r wine --version || true
echo "=== SELESAI. Lanjut script 02_hubungkan_ke_folder_mod.sh ==="

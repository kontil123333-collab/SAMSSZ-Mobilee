package com.samssz.mobile;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * SAMSSZ Mobile
 *
 * Native Android front-end for the core PC <-> PS4 model conversion logic in
 * the supplied SamsszConverter.py. The desktop-only RPF/OTD builder remains
 * explicitly marked in the UI rather than pretending that a Windows runtime
 * exists on Android.
 */
public class MainActivity extends Activity {
    private static final int PICK_TREE = 1001;
    private Uri selectedTree;
    private TextView pathLabel;
    private TextView logView;

    private static final Map<String,String> PC_TO_PS4 = new LinkedHashMap<>();
    private static final Map<String,String> PS4_TO_PC = new LinkedHashMap<>();
    private static final Set<String> PATCH_EXTS = new HashSet<>();
    static {
        addPair(".yft", ".oft", true);
        addPair(".ydr", ".odr", true);
        addPair(".ydd", ".odd", true);
        addPair(".ypt", ".opt", true);
        addPair(".ybn", ".obn", true);
        addPair(".ybd", ".obd", true);
        addPair(".ycd", ".ocd", false);
        addPair(".ymap", ".omap", false);
        addPair(".ytyp", ".otyp", false);
        addPair(".ymt", ".omt", false);
        addPair(".ymf", ".omf", false);
    }
    private static void addPair(String pc, String ps4, boolean patch) {
        PC_TO_PS4.put(pc, ps4);
        PS4_TO_PC.put(ps4, pc);
        if (patch) PATCH_EXTS.add(pc);
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF080B12);
        getWindow().setNavigationBarColor(0xFF080B12);
        buildUi();
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView tv(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(bold ? Typeface.create("sans", Typeface.BOLD) : Typeface.create("sans", Typeface.NORMAL));
        t.setIncludeFontPadding(false);
        return t;
    }

    private View spacer(int h) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h))); return v; }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFF080B12);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(28));
        scroll.addView(root);

        TextView brand = tv("SAMSSZ", 38, 0xFF2DE1FF, true);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView sub = tv("GTA V TOOLKIT  •  MOBILE EDITION", 12, 0xFF8D9AB3, true);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(-1, dp(24)));
        root.addView(spacer(12));

        LinearLayout hero = card();
        TextView heroTitle = tv("NEON FORGE", 18, 0xFFF4F7FF, true);
        hero.addView(heroTitle);
        TextView heroBody = tv("PC ↔ PS4 model conversion\nNative Android file access • offline core", 13, 0xFF8D9AB3, false);
        heroBody.setPadding(0, dp(7), 0, 0);
        hero.addView(heroBody);
        root.addView(hero);
        root.addView(spacer(12));

        LinearLayout select = card();
        TextView st = tv("WORKSPACE", 12, 0xFF25D9FF, true);
        select.addView(st);
        pathLabel = tv("Belum ada folder dipilih", 13, 0xFF8D9AB3, false);
        pathLabel.setPadding(0, dp(7), 0, dp(10));
        select.addView(pathLabel);
        TextView pick = button("PILIH FOLDER", 0xFF13283D, 0xFF25D9FF);
        pick.setOnClickListener(v -> chooseFolder());
        select.addView(pick);
        root.addView(select);
        root.addView(spacer(14));

        TextView section = tv("TOOLS", 12, 0xFF8D9AB3, true);
        section.setPadding(dp(2), 0, 0, dp(8));
        root.addView(section);

        addTool(root, "01", "SMART MOD BUILDER", "Scan folder → convert all supported resources", v -> runSmart(false));
        addTool(root, "02", "FULL VEHICLE PIPELINE", "Scan archive/folder inputs and convert supported models", v -> runSmart(false));
        addTool(root, "03", "AUTO SCAN CONVERT", "Recursive scan + ZIP extraction + model conversion", v -> runAutoScan());
        addTool(root, "04", "EXTRACT  •  RPF / YTD", "Desktop engine bridge required for native RPF/YTD extraction", v -> unsupported("RPF/YTD extraction requires the desktop runtime in the supplied tool."));
        addTool(root, "05", "BUILD  •  RPF / OTD", "Desktop engine bridge required for RageBuilder", v -> unsupported("RPF/OTD build uses ragebuilder.exe in the supplied Python tool."));
        addTool(root, "06", "CONVERT TO PC", "PS4 OFT/ODR/... → PC YFT/YDR/...", v -> runSmart(true));
        addTool(root, "07", "SAMSSZ AI CORE", "Offline diagnostics and supported-format help", v -> showAiCore());
        addTool(root, "08", "QUICK HELP", "How each menu works on Android", v -> showHelp());
        addTool(root, "09", "SYSTEM INFO", "Engine, version and supported formats", v -> showSystemInfo());
        addTool(root, "10", "CHANGE LOG", "Mobile port notes", v -> showChangelog());
        addTool(root, "11", "EXIT", "Close SAMSSZ Mobile", v -> finish());

        root.addView(spacer(12));
        LinearLayout logCard = card();
        TextView lt = tv("ACTIVITY", 12, 0xFF25D9FF, true);
        logCard.addView(lt);
        logView = tv("Ready. Pilih folder untuk mulai.", 12, 0xFFCBD4E6, false);
        logView.setPadding(0, dp(8), 0, 0);
        logCard.addView(logView);
        root.addView(logCard);

        setContentView(scroll);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(13), dp(14), dp(13));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xFF101623);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), 0xFF1E3148);
        c.setBackground(bg);
        c.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return c;
    }

    private TextView button(String label, int bgColor, int textColor) {
        TextView b = tv(label, 13, textColor, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(10), dp(12), dp(10), dp(12));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(bgColor);
        bg.setCornerRadius(dp(14));
        b.setBackground(bg);
        return b;
    }

    private void addTool(LinearLayout root, String no, String title, String desc, View.OnClickListener click) {
        LinearLayout row = card();
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView n = tv(no, 12, 0xFF25D9FF, true);
        n.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable nb = new android.graphics.drawable.GradientDrawable();
        nb.setColor(0xFF13283D); nb.setCornerRadius(dp(9)); nb.setStroke(dp(1), 0xFF245B7A);
        n.setBackground(nb); n.setPadding(dp(8),dp(6),dp(8),dp(6));
        head.addView(n, new LinearLayout.LayoutParams(dp(42), dp(34)));
        LinearLayout textBox = new LinearLayout(this); textBox.setOrientation(LinearLayout.VERTICAL); textBox.setPadding(dp(10),0,dp(8),0);
        textBox.addView(tv(title, 14, 0xFFF4F7FF, true));
        textBox.addView(tv(desc, 11, 0xFF8D9AB3, false));
        head.addView(textBox, new LinearLayout.LayoutParams(0, -2, 1));
        TextView go = button("OPEN", 0xFF152031, 0xFF8EDFFF);
        go.setOnClickListener(click);
        head.addView(go, new LinearLayout.LayoutParams(dp(74), dp(42)));
        row.addView(head);
        LinearLayout.LayoutParams rp = (LinearLayout.LayoutParams) row.getLayoutParams(); rp.bottomMargin = dp(9); row.setLayoutParams(rp);
        root.addView(row);
    }

    private void chooseFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, PICK_TREE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_TREE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedTree = data.getData();
            final int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try { getContentResolver().takePersistableUriPermission(selectedTree, flags); } catch (Exception ignored) {}
            pathLabel.setText("Folder dipilih ✓\n" + selectedTree);
            log("Workspace siap: " + selectedTree);
        }
    }

    private void requireFolder(Runnable r) {
        if (selectedTree == null) { Toast.makeText(this, "Pilih folder dulu.", Toast.LENGTH_SHORT).show(); return; }
        new Thread(() -> { try { r.run(); } catch (Throwable e) { log("ERROR: " + e.getMessage()); } }).start();
    }

    private void runSmart(boolean pcOnly) {
        requireFolder(() -> {
            List<DocumentNode> files = listTree(selectedTree);
            int success=0, fail=0, found=0;
            for (DocumentNode n : files) {
                String lower=n.name.toLowerCase(Locale.ROOT);
                String ext=extension(lower);
                boolean accepted = pcOnly ? PS4_TO_PC.containsKey(ext) : (PC_TO_PS4.containsKey(ext) || PS4_TO_PC.containsKey(ext));
                if (!accepted) continue;
                found++;
                try {
                    Uri out = createSiblingOutput(selectedTree, n.name, targetExt(ext));
                    byte[] in = readAll(n.uri);
                    byte[] result = ModelConverter.convert(in, ext);
                    writeAll(out, result);
                    success++;
                    log((pcOnly?"PC": "SMART") + " ✓ " + n.name + " → " + targetExt(ext));
                } catch (Exception e) { fail++; log("✕ " + n.name + " : " + e.getMessage()); }
            }
            log("DONE • detected="+found+" success="+success+" failed="+fail);
        });
    }

    private void runAutoScan() {
        requireFolder(() -> {
            List<DocumentNode> files = listTree(selectedTree);
            int supported=0, zip=0, converted=0;
            for (DocumentNode n: files) {
                String ext=extension(n.name.toLowerCase(Locale.ROOT));
                if (PC_TO_PS4.containsKey(ext) || PS4_TO_PC.containsKey(ext)) {
                    supported++;
                    try {
                        Uri out=createOutput(n.name,targetExt(ext));
                        writeAll(out,ModelConverter.convert(readAll(n.uri),ext));
                        converted++;
                    } catch(Exception e){ log("✕ "+n.name+" : "+e.getMessage()); }
                } else if (".zip".equals(ext)) {
                    zip++;
                    converted += convertZip(n.uri, n.name);
                }
            }
            log("AUTO SCAN • models="+supported+" zip="+zip+" converted="+converted+".");
            if (zip>0) log("ZIP archives are processed with Android's built-in ZIP reader.");
        });
    }

    private String targetExt(String ext) { return PC_TO_PS4.containsKey(ext) ? PC_TO_PS4.get(ext) : PS4_TO_PC.get(ext); }

    private void unsupported(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); log("INFO: " + msg); }

    private void showAiCore(){ log("AI CORE: offline mode • checks folder • detects supported model formats • reports failures without deleting originals."); }
    private void showHelp(){ log("1 Smart scan/convert • 2 same core pipeline • 3 recursive scan • 4/5 desktop runtime dependent • 6 PS4→PC • 7 diagnostics • 8 help • 9 info • 10 changelog • 11 exit."); }
    private void showSystemInfo(){ log("SAMSSZ Mobile 1.0 • Android native UI • model matrix mirrored from supplied SamsszConverter.py. RPF/OTD native builder is not claimed on Android."); }
    private void showChangelog(){ log("Mobile port: neon UI, SAF folder picker, PC↔PS4 model conversion, safe output naming, async processing. Desktop-only RageBuilder paths remain explicit."); }

    private void log(String s) { runOnUiThread(() -> { if (logView != null) logView.setText(s); }); }

    private static String extension(String name){ int i=name.lastIndexOf('.'); return i>=0?name.substring(i):""; }

    private static byte[] readAll(Uri uri) throws Exception {
        ContentResolver cr = AppHolder.activity.getContentResolver();
        try(InputStream in=cr.openInputStream(uri); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            if(in==null) throw new Exception("cannot open input");
            byte[] buf=new byte[65536]; int n; while((n=in.read(buf))>=0) out.write(buf,0,n); return out.toByteArray();
        }
    }
    private void writeAll(Uri uri, byte[] data) throws Exception {
        try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){
            if(out==null) throw new Exception("cannot open output"); out.write(data); out.flush();
        }
    }

    private Uri createSiblingOutput(Uri tree, String original, String outExt) throws Exception {
        // Android SAF createDocument() returns a Uri. Keep all converted files
        // inside the app's dedicated output folder, while preserving the
        // original filename and adding a duplicate-safe suffix.
        return createOutput(original, outExt);
    }

    private Uri createOutput(String original, String outExt) throws Exception {
        Uri folder=ensureOutputFolder();
        String base=original; int dot=base.lastIndexOf('.'); if(dot>0) base=base.substring(0,dot);
        String candidate=base+outExt; int i=1;
        while (existsChild(folder,candidate)) candidate=base+" ("+(i++)+")"+outExt;
        Uri created=DocumentsContract.createDocument(getContentResolver(), folder, "application/octet-stream", candidate);
        if(created==null) throw new Exception("create output failed");
        return created;
    }

    private Uri ensureOutputFolder() throws Exception {
        String rootId=DocumentsContract.getTreeDocumentId(selectedTree);
        Uri rootDoc=DocumentsContract.buildDocumentUriUsingTree(selectedTree,rootId);
        Uri existing=findChild(rootDoc,"Samssz_Converted");
        if(existing!=null)return existing;
        Uri made=DocumentsContract.createDocument(getContentResolver(),rootDoc,DocumentsContract.Document.MIME_TYPE_DIR,"Samssz_Converted");
        if(made==null)throw new Exception("cannot create output folder");
        return made;
    }

    private boolean existsChild(Uri parent,String name){ return findChild(parent,name)!=null; }
    private Uri findChild(Uri parent,String wanted){
        String id=DocumentsContract.getDocumentId(parent);
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(parent,id);
        String[] proj={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME};
        try(android.database.Cursor c=getContentResolver().query(children,proj,null,null,null)){
            if(c==null)return null; int idIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID); int nameIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            while(c.moveToNext()){ if(wanted.equals(c.getString(nameIx))) return DocumentsContract.buildDocumentUriUsingTree(selectedTree,c.getString(idIx)); }
        }catch(Exception ignored){}
        return null;
    }

    private int convertZip(Uri zipUri,String archiveName) {
        int count=0;
        try(InputStream in=getContentResolver().openInputStream(zipUri)) {
            if(in==null) return 0;
            try(ZipInputStream zis=new ZipInputStream(in)) {
                ZipEntry e; byte[] buf=new byte[65536];
                while((e=zis.getNextEntry())!=null){
                    if(e.isDirectory())continue; String name=e.getName(); String ext=extension(name.toLowerCase(Locale.ROOT));
                    if(!(PC_TO_PS4.containsKey(ext)||PS4_TO_PC.containsKey(ext)))continue;
                    ByteArrayOutputStream tmp=new ByteArrayOutputStream(); int n; while((n=zis.read(buf))>0)tmp.write(buf,0,n);
                    Uri out=createOutput(new java.io.File(name).getName(),targetExt(ext)); writeAll(out,ModelConverter.convert(tmp.toByteArray(),ext)); count++;
                    log("ZIP ✓ "+archiveName+" :: "+name);
                }
            }
        }catch(Exception ex){ log("ZIP ERROR "+archiveName+" : "+ex.getMessage()); }
        return count;
    }

    private List<DocumentNode> listTree(Uri tree) {
        List<DocumentNode> out=new ArrayList<>();
        crawl(tree,out,0);
        return out;
    }
    private void crawl(Uri parent,List<DocumentNode> out,int depth){
        if(depth>16)return;
        String docId=DocumentsContract.getTreeDocumentId(parent);
        Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(parent,docId);
        String[] proj={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_FLAGS};
        try(android.database.Cursor c=getContentResolver().query(children,proj,null,null,null)){
            if(c==null)return;
            int idIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            int mimeIx=c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
            while(c.moveToNext()){
                String id=c.getString(idIx); String name=c.getString(nameIx); String mime=c.getString(mimeIx);
                Uri child=DocumentsContract.buildDocumentUriUsingTree(parent,id);
                if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) { if(!"Samssz_Converted".equalsIgnoreCase(name)) crawl(child,out,depth+1); } else out.add(new DocumentNode(name,child));
            }
        }catch(Exception e){ log("SCAN ERROR: "+e.getMessage()); }
    }

    private static class DocumentNode { final String name; final Uri uri; DocumentNode(String n,Uri u){name=n;uri=u;} }
    private static class AppHolder { static Activity activity; }
    @Override protected void onResume(){ super.onResume(); AppHolder.activity=this; }

    // Core converter mirrors the supplied Python Model Forge algorithm:
    // 16-byte RSC7 header + raw-deflate payload + GTAV1/PS4 byte replacement.
    private static class ModelConverter {
        static byte[] convert(byte[] data,String ext) throws Exception {
            String outExt = PC_TO_PS4.containsKey(ext) ? PC_TO_PS4.get(ext) : PS4_TO_PC.get(ext);
            if(outExt==null) throw new Exception("unsupported extension");
            if(!PATCH_EXTS.contains(ext) && !isPatchPs4(ext)) return Arrays.copyOf(data,data.length);
            if(data.length<4 || !(data[0]=='R'&&data[1]=='S'&&data[2]=='C'&&data[3]=='7')) return Arrays.copyOf(data,data.length);
            if(data.length<16) throw new Exception("RSC7 header truncated");
            byte[] header=Arrays.copyOfRange(data,0,16);
            byte[] comp=Arrays.copyOfRange(data,16,data.length);
            byte[] dec=inflateRaw(comp);
            byte[] gtav1=longLE(0x7755555555996996L);
            byte[] ps4=longLE(8598872888530528406L);
            boolean pc2ps4=PC_TO_PS4.containsKey(ext);
            byte[] from=pc2ps4?gtav1:ps4, to=pc2ps4?ps4:gtav1;
            int count=countSeq(dec,from);
            if(count>0) dec=replaceSeq(dec,from,to);
            byte[] raw=deflateRaw(dec);
            byte[] out=new byte[header.length+raw.length];
            System.arraycopy(header,0,out,0,header.length); System.arraycopy(raw,0,out,header.length,raw.length);
            return out;
        }
        static boolean isPatchPs4(String ext){ return ext.equals(".oft")||ext.equals(".odr")||ext.equals(".odd")||ext.equals(".opt")||ext.equals(".obn")||ext.equals(".obd"); }
        static byte[] longLE(long v){ byte[] b=new byte[8]; for(int i=0;i<8;i++)b[i]=(byte)(v>>(8*i)); return b; }
        static int countSeq(byte[] a,byte[] b){ int n=0; outer: for(int i=0;i<=a.length-b.length;i++){for(int j=0;j<b.length;j++)if(a[i+j]!=b[j])continue outer;n++;} return n; }
        static byte[] replaceSeq(byte[] a,byte[] from,byte[] to){ byte[] out=new byte[a.length]; int oi=0; for(int i=0;i<a.length;){boolean ok=i+from.length<=a.length; if(ok){for(int j=0;j<from.length;j++)if(a[i+j]!=from[j]){ok=false;break;}} if(ok){System.arraycopy(to,0,out,oi,to.length);oi+=to.length;i+=from.length;} else {out[oi++]=a[i++];}} return Arrays.copyOf(out,oi); }
        static byte[] inflateRaw(byte[] data) throws Exception { Inflater inf=new Inflater(true); inf.setInput(data); ByteArrayOutputStream out=new ByteArrayOutputStream(Math.max(1024,data.length*2)); byte[] buf=new byte[65536]; try{while(!inf.finished()){int n=inf.inflate(buf); if(n==0){if(inf.needsDictionary()) throw new Exception("deflate dictionary required"); if(inf.needsInput()) break;} out.write(buf,0,n);} if(!inf.finished()) throw new Exception("deflate stream incomplete"); return out.toByteArray();} finally{inf.end();}}
        static byte[] deflateRaw(byte[] data){ Deflater d=new Deflater(9,true); d.setInput(data); d.finish(); ByteArrayOutputStream out=new ByteArrayOutputStream(data.length/2+64); byte[] buf=new byte[65536]; while(!d.finished()){int n=d.deflate(buf); out.write(buf,0,n);} d.end(); return out.toByteArray(); }
    }
}
